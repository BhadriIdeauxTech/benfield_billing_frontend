import React, { useEffect, useState } from 'react'
import { Route, Routes, useNavigate } from 'react-router-dom'
import Page from '../../Modules/Page/Container/index'
import { authenticated } from '../config/user'
import Flex from '../../Components/Flex'
import styled from 'styled-components'
import { useSelector } from 'react-redux'

const PageFlex = styled(Flex)`
  overflow: hidden;
  `
const AuthPage = ({ isAuthenticated }) => {
  const navigate = useNavigate()

  const [authenticatedRoutes, setAuthenticatedRoutes] = useState([]);

  const UserRole = useSelector((state) => state?.auth?.token?.role)
  console.log(isAuthenticated, UserRole, 'Auth')


     // if (!isAuthenticated) {
    //   console.log(isAuthenticated, 'called')
    //   navigate('/signin')
    // }
    // NoGST-Biller

      // if (UserRole === 'Admin') {
      //   console.log('Admin')
      // }

  useEffect(() => {
 
    if (isAuthenticated) {
      // if (UserRole === 'Admin') {
        
        // } else if (UserRole === 'NoGST-Biller') {
          //   setAuthenticatedRoutes(authenticated2);
          // } else {
            //   console.log('Unknown User Type');
            // }
              setAuthenticatedRoutes(authenticated);
    }
    else {
        console.log(isAuthenticated, 'called')
        navigate('/signin')
    }
  }, [isAuthenticated]) 
  // UserRole
  
  return (
    <PageFlex>
      {isAuthenticated && (
        <>
          <Page>
            <Routes>
              {authenticatedRoutes.map(({ routePath, Component }) => {
                return (
                  <Route
                    key={routePath}
                    path={routePath}
                    element={<Component />}
                  ></Route>
                )
              })}
            </Routes>
          </Page>
        </>
      )}
    </PageFlex>
  )
}

export default AuthPage
