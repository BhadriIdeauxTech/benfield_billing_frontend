import PageNotFound from '../Components/PageNotFound'
import UserSignin from '../../Modules/Auth/Container/index'
import Dashboard from '../../Modules/Dashboard'
import SalesMain from '../../Modules/Sales/Container/index'
import SalesReturn from '../../Modules/SalesReturn'
import Purchase from '../../Modules/Purchase/Purchase'
import PurchaseReturn from '../../Modules/Purchase/PurchaseReturn'
import Estimate from '../../Modules/Estimate'
import Expense from '../../Modules/Expense'
import AddSpplier from '../../Modules/Suppliers/AddSupplier'
import EditSppliers from '../../Modules/Suppliers/EditSupplier/Container/index'
import SupplierPayment from '../../Modules/Suppliers/SupplierPayment/Container/index'
import EditSupplierPayment from '../../Modules/Suppliers/EditSupplierPayement/Container/index'
import AddCustomers from '../../Modules/Customers/AddCustomers'
import CustomerEdit from '../../Modules/Customers/EditCustomers/Container/index'
import CustomerPaymentDetails from '../../Modules/Customers/CustomerPayment/Container/index'
import CustomerEditPayment from '../../Modules/Customers/EditPaymentCustomer/Container/index'
import { AddProduct } from '../../Modules/Products/Add Items'
import { ViewItem } from '../../Modules/Products/Add Items/Partials/ViewItem'
import BusinessProfiles from '../../Modules/BusinessProfile/AddBusiness'
import EditBusinessProfiles from '../../Modules/BusinessProfile/EditProfile'
import AddMembers from '../../Modules/Members/AddMembers'
import MemberList from '../../Modules/Members/MemberList/Container/index'
import SaleReportMain from '../../Modules/Reports/SaleReport'
import PurchaseReportMain from '../../Modules/Reports/PurchaseReport'
import SalesReturnReportMain from '../../Modules/Reports/SalesReturnReport'
import PurchaseReturnReportMain from '../../Modules/Reports/PrchaseReturnReport'
import QuatationReportMain from '../../Modules/Reports/QuatationReport'
import ExpenseReportMain from '../../Modules/Reports/Expense'
import SupplierProfiles from '../../Modules/Suppliers/SupplierProfile/Container/index'
import CustomerProfiles from '../../Modules/Customers/CustomerProfile/Container/index'
import DayBook from '../../Modules/DayBook/Container/index'

export const anonymous = [
  {
    routePath: '/signin',
    Component: UserSignin,
  },
]

export const authenticated = [
  {
    routePath: '/',
    Component: Dashboard,
  },
  {
    routePath: 'sales_page/',
    Component: SalesMain,
  },
  {
    routePath: 'sales_return/',
    Component: SalesReturn,
  },
  {
    routePath: 'purchase/',
    Component: Purchase,
  },
  {
    routePath: 'purchase_return/',
    Component: PurchaseReturn,
  },
  {
    routePath: 'estimate/',
    Component: Estimate,
  },
  {
    routePath: 'expense/',
    Component: Expense,
  },
  {
    routePath: 'add_supplier/',
    Component: AddSpplier,
  },
  {
    routePath: 'edit_suplier/',
    Component: EditSppliers,
  },
  {
    routePath: 'supplier_payments/',
    Component: SupplierPayment,
  },
  {
    routePath: 'editpayment_supplier/',
    Component: EditSupplierPayment,
  },
  {
    routePath: 'addcustomers/',
    Component: AddCustomers,
  },
  {
    routePath: 'editcustomers/',
    Component: CustomerEdit,
  },
  {
    routePath: 'customerpayment/',
    Component: CustomerPaymentDetails,
  },
  {
    routePath: 'editpayment/',
    Component: CustomerEditPayment,
  },
  {
    routePath: 'addproduct/',
    Component: AddProduct,
  },
  {
    routePath: 'viewproduct/',
    Component: ViewItem,
  },
  {
    routePath: 'business_profile/',
    Component: BusinessProfiles,
  },
  {
    routePath: 'edit_business_profile/',
    Component: EditBusinessProfiles,
  },
  {
    routePath: 'add_members/',
    Component: AddMembers,
  },
  {
    routePath: 'member_list/',
    Component: MemberList,
  },
  {
    routePath: 'sales_report/',
    Component: SaleReportMain,
  },
  {
    routePath: 'purchase_report/',
    Component: PurchaseReportMain,
  },
  {
    routePath: 'salereturn_report/',
    Component: SalesReturnReportMain,
  },
  {
    routePath: 'purchasereturn_report/',
    Component: PurchaseReturnReportMain,
  },
  {
    routePath: 'quotation_report/',
    Component: QuatationReportMain,
  },
  {
    routePath: 'expense_report/',
    Component: ExpenseReportMain,
  },
  {
    routePath: 'daybook/',
    Component: DayBook,
  },
  {
    routePath: 'SupplierProfiles/:id',
    Component: SupplierProfiles,
  },
  {
    routePath: 'CustomerProfiless/:id',
    Component: CustomerProfiles,
  },
  {
    routePath: '*',
    Component: PageNotFound,
  },
]

// export const authenticated2 = [
//   {
//     routePath: '/',
//     Component: Home2,
//   },
//   {
//     routePath: '*',
//     Component: PageNotFound,
//   },
// ]
