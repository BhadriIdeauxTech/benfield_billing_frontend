import React from 'react'
import styled from 'styled-components'
import { THEME } from '../../theme';

export const FoemTitle  = styled.div`
& h5 {
    font-size: 25px;
    color: var(--dark-color);
    font-weight: 600;
    text-transform:capitalize;
    margin-bottom:20px;
}
`;

export const FormTitle = ({Title}) => {
  return (
    <FoemTitle>
        <h5>{Title}</h5>
    </FoemTitle>
  )
}

