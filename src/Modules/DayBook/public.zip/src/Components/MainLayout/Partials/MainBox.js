import React from 'react'
import { BottomLIst } from './Styled'

export const Mainbox = ({secondbox}) => {
  return (
    <BottomLIst>
      {secondbox}
    </BottomLIst>
  )
}
