// import { StockOutlined, PrinterOutlined, UsergroupAddOutlined, SolutionOutlined, AreaChartOutlined, FileProtectOutlined, SnippetsFilled, ScheduleOutlined, WalletOutlined, FileSearchOutlined } from "@ant-design/icons";
// import { SiCoinmarketcap, SiExpensify } from 'react-icons/si';
import { MdAdminPanelSettings, MdCrisisAlert, MdEmojiTransportation, MdOutlineInventory, MdOutlineToday, MdProductionQuantityLimits } from 'react-icons/md'
// import { GoListUnordered } from 'react-icons/go'
// import { FaUserEdit } from 'react-icons/fa'
import { Menu } from "antd";
// import { BsFillBuildingsFill } from "react-icons/bs";
import { useNavigate } from 'react-router-dom';
// import { BsDistributeHorizontal, BsFillChatTextFill } from "react-icons/bs";
// import { BiPurchaseTag, BiPurchaseTagAlt } from "react-icons/bi";
// import { IoMdToday } from 'react-icons/io'
import { useState } from "react";
import { LoginOutlined, UserOutlined, UsergroupAddOutlined } from '@ant-design/icons';
import { BsDistributeHorizontal } from 'react-icons/bs';
// import { TbBusinessplan, TbReportAnalytics } from "react-icons/tb";
function getItem(label, key, icon, children, type) {
  return {
    key,
    icon,
    children,
    label,
    type,
  };
}

const items = [
  getItem('Dashboard', ''),

  //============== Admin Page start =================

  getItem('Sales', 'sub1', <UsergroupAddOutlined />, [
    getItem('Sales Page', 'sales_page'),
    getItem('Sales Return', 'sales_return'),
  ]),
  getItem('Purchase', 'sub2', <UsergroupAddOutlined />, [
    getItem('Purchase', 'purchase'),
    getItem('Purchase Return', 'purchase_return')
  ]),

  getItem('Quotation', 'estimate',  <UsergroupAddOutlined />),

  getItem('Expense', 'expense', <UsergroupAddOutlined />),

  getItem('Supplier', 'sub3', <UsergroupAddOutlined />, [
    getItem('Add Supplier', 'add_supplier'),
    getItem('View Supplier', 'edit_suplier'),
    getItem('Supplier Payement', 'supplier_payments'),
    getItem('View Supplier Payement', 'editpayment_supplier'),
  ]),
  getItem('Customers', 'sub4', <UsergroupAddOutlined />, [
    getItem('Add Customers', 'addcustomers'),
    getItem('View Customer', 'editcustomers'),
    getItem('Customers Payement', 'customerpayment'),
    getItem('View Payement', 'editpayment'),
  ]),
  getItem('Product', 'sub5', <UsergroupAddOutlined />, [
    getItem('Add Product', 'addproduct'),
    getItem('View Product', 'viewproduct'),
  ]),
  getItem('Business Profile', 'sub6', <UserOutlined />, [
    getItem('Profile', 'business_profile'),
    getItem('View Profile', 'edit_business_profile'),
  ]),

  getItem('User Create', 'sub7', <UsergroupAddOutlined />, [
    getItem('Add User', 'add_members'),
    getItem('User List', 'member_list'),
  ]),

  getItem('Report', 'sub8', <UsergroupAddOutlined />, [
    getItem('Sales', 'sales_report'),
    getItem('Purchase', 'purchase_report'),
    getItem('Sale Return', 'salereturn_report'),
    getItem('Purchase Return', 'purchasereturn_report'),
    getItem('Quatation', 'quotation_report'),
    getItem('Expense', 'expense_report'),
    // getItem('Total Customers', 'totalcustomer_report'),
    // getItem('Total Supplier', 'supplier_report'),
  ]),
  getItem('Daybook', 'daybook'),
  // getItem('Admin', 'sub8', <MdAdminPanelSettings />, [

    // getItem('Products', 'sub9', <UsergroupAddOutlined />, [
    //   getItem('Add Items', 'add_items'),
    // ]),
    // getItem('Payments', 'sub12', <UsergroupAddOutlined />, [
    //   getItem('Customer Payments', 'customer_payments'),
    // ]),


  // ])
];

const SideMenu = () => {
  const rootSubinmenuKeys = ['sub1', 'sub2', 'sub3', 'sub4', 'sub5', 'sub7'];
  const [openKeys, setOpenKeys] = useState(['sub1']);
  const onOpenChange = (keys) => {
    const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
    if (rootSubinmenuKeys.indexOf(latestOpenKey) === -1) {
      setOpenKeys(keys);
    } else {
      setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
    }
  };

  // const onOopenSub = (keys) => {
  //   const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
  //   if (rootSubinmenuKeys.indexOf(latestOpenKey) === -1) {
  //     setOpenKeys(keys);
  //   } else {
  //     setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
  //   }
  // };

  const navigate = useNavigate();
  const onClick = ({ key }) => {

    if (key === null) {
      console.log('no navigate')

    }
    else {
      navigate(`${key}/`)
    }
  }
  return (
    <>

      <Menu
        onClick={onClick}
        // openKeys={openKeys}
        onOpenChange={onOpenChange}
        defaultSelectedKeys={['1']}
        // onClick={()=> onOopenSub()}
        defaultOpenKeys={['sub1']}
        mode="inline"
        items={items}
      />
    </>
  )
}

export default SideMenu
