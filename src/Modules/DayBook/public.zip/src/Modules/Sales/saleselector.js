const getSale = state => state.AddingSale.sale

const selectors = {
    getSale, 
}

export default selectors