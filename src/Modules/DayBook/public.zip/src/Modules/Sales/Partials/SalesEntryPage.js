import { Card, Col, Divider, Form, Popover } from "antd"
import React, { Fragment, useEffect, useState } from "react"
import Flex from "../../../Components/Flex";
import { DeleteButtonWrapper, Table } from "../../../Components/Table";
import Button from "../../../Components/Form/Button";
import { DeleteOutlined } from "@ant-design/icons";
import { CustomInputNumber } from "../../../Components/Form/CustomInputNumber";
import { Row } from "../../../Components/Row";
import { SaleHeader } from "../../SalesReturn/Partials/style";
import { SalesFormHeader } from "./SalesFormHeader";
import { SalesFormFooter } from "./SalesFormFooter";
import { Modal } from "../../../Components/Modal";
import { Select } from "../../../Components/Form/Select";
import Input from "../../../Components/Form/Input";
import dayjs from 'dayjs'
import OutSourceData from './Data'
import request from "../../../utils/request";



export const SalesEntryPage = ({ setSale }) => {

  const [count, setCount] = useState(1);

  const [switchValue, setSwitchValue] = useState(false)
  const [payment, setPayment] = useState('cash');
  const [roundOff, setRoundOff] = useState(false);

  const URL = 'sales/add_sale/'

  const [selectedDate, setSelectedDate] = useState(dayjs().format('YYYY-MM-DD'));

  const [getdata, setGetdata] = useState([])

  const [selectedSale, setSelectedSale] = useState({})

  // ======  Modal Open ========
  const [isModalOpen, setIsModalOpen] = useState(false);

  // ======  Modal Title and Content ========
  const [modalTitle, setModalTitle] = useState("");
  const [modalContent, setModalContent] = useState(null);

  // ================  SalesFormFooter checked ==========
  const [round, setRound] = useState(false);
  const [roundDecimalValue, setRoundDecimalValue] = useState(null);
  const [balance, setBalance] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState({})

  // -----------------  Balance Checking ------------
  const [withDecimal, setWithDecimal] = useState(null);
  const [withOutDecimal, setWithOutDecimal] = useState(null);
  const [balanceChangeAmount, setBalanceChangeAmount] = useState(0);
  const [balanceChange, setBalanceChange] = useState(false);



  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const [form] = Form.useForm();


  // =========================  Modal Content Start  ===========================

  // ===========  ITEM MODAL SHOW  ==================
  const handleItemModalShow = () => {
    setModalTitle("Add Item");
    setModalContent(<ItemModalViewContent />);
    showModal();
  };

  const handleItemModalShows = () => {
    setModalTitle("Add Item");
    setModalContent(<ItemModalViewContents />);
    showModal();
  };

  const ItemModalViewContent = () => {
    return (
      <h1>Vijay</h1>
    )
  };


  useEffect(() => {
    form.setFieldsValue({ customer: selectedSale.id })
    form.setFieldsValue({ customer_name: selectedSale.customer_name })
    form.setFieldsValue({ GSTIN: selectedSale.gstin })
    form.setFieldsValue({ email: selectedSale.email })
    form.setFieldsValue({ company_name: selectedSale.customer_company_name })
    form.setFieldsValue({ address: selectedSale.customer_address })
    form.setFieldsValue({ old_balance: selectedSale.credit_amt_balance })
    form.setFieldsValue({ advanced_amt: selectedSale.advanced_amt })
    form.setFieldsValue({ item_hsn: selectedSale.item_hsn })
    form.setFieldsValue({ unit: selectedSale.unit })
    form.setFieldsValue({ mobile_number: selectedSale.mobile_number })


  }, [selectedSale])


  console.log(selectedSale, 'selectedSaleselectedSaleselectedSale')

  // ===========  Sale MobileNumber Data =========
  useEffect(() => {
    GetSaleCustomer();
  }, [])
  const GetSaleCustomer = () => {
    request.get('sales/get_detail_sale/')
      .then(function (response) {
        console.log(response.data, 'sale');
        setGetdata(response.data.item)
        // setSale(response.data)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  console.log(getdata,'ffffffffffffffffffffff')

  const ItemModalViewContents = () => {
    return (
      <h1>checkingggggggggg</h1>
    )
  }

  // -----------------------  RoundOff Checked Function ----------
  const RoundOffChecked = (value) => {
    setWithDecimal(tableSecondaryData[0].grand_total - roundDecimalValue);
    setRound(value)
  }

  const TotalBalance = (value) => {
    setBalance(value)
    setWithDecimal(tableSecondaryData[0].grand_total - roundDecimalValue);
    setWithOutDecimal(tableSecondaryData[0].grand_total)
  }
  console.log(withDecimal, 'cr')
  console.log(withOutDecimal, 'eeeevall')

  const AddSale = (values) => {
    request.post(`${URL}`, values)
      .then(function (response) {
        console.log(response);
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  // =========================  Modal Content End  ===========================

  // =========================  Other Functions start  =========================

  const handlePayment = (e) => {
    setPayment(e)
  }

  // =========================  Other Functions End  =========================

  const initialData = [
    {
      key: 0,
      sales: '',
      item_hsn: '',
      description: '',
      quantity: '',
      unit: '',
      sale_price: '',
      discount_percentage: '',
      sale_discount: '',
      tax_percentage: '',
      tax_cal_amt: '',
      item_cal_total_amt: '',
    }
  ];

  const secondaryData = [
    {
      qty_total: '',
      discount_total: '',
      tax_total: '',
      grand_total: '',
    },
  ];

  const footerCalData = [
    {
      roundoff: '',
      sub_total: '',
      grand_total: '',
      total_rowamount: '',
      received_amt: '',
      balance: '',
    },
  ];


  // const keyvalueData = [
  //   {
  //     user: '',
  //     customer:
  //     customer_name,
  //     invoice_no,
  //     mobile_number,
  //     invoice_date,
  //     state_of_supply,
  //     Address,
  //     received_amt,
  //     round_off,
  //     round_off_value,
  //     GSTIN,
  //     email,
  //     credit_amt,
  //     payment_type,
  //     reference_no,
  //     credit_period,
  //     old_balance,
  //     sales,
  //     advanced_amt,
  //     received_amt,
  //     balance,
  //     credit_limit,
  //     grand_total,
  //     tax_total,
  //     discount_total,
  //   }
  //   ss: [
  //     {
  //       item,
  //       item_hsn,
  //       quantity,
  //       unit,
  //       mrp,
  //       sale_price,
  //       discount_percentage,
  //       sale_discount,
  //       tax_percentage,
  //       tax_cal_amt,
  //       item,cal_total_amt
  //     }
  //   ]
  // ]




  const [tableData, setTableData] = useState(initialData);
  const [tableSecondaryData, setTableSecondaryData] = useState(secondaryData);
  const [tableFooterData, setTableFooterData] = useState(footerCalData);


  // +++++++++++++++++++++   Use Effects Start +++++++++++++++++++

  // ------------------  Dynamic Table  --------------------

  useEffect(() => {
    tableData.forEach(record => {
      form.setFieldsValue({ [`sales${record.key}`]: record.sales });
      form.setFieldsValue({ [`item_hsn${record.key}`]: record.item_hsn });
      // form.setFieldsValue({ [`description${record.key}`]: record.description });
      form.setFieldsValue({ [`quantity${record.key}`]: record.quantity });
      form.setFieldsValue({ [`unit${record.key}`]: record.unit });
      form.setFieldsValue({ [`sale_price${record.key}`]: record.sale_price });
      form.setFieldsValue({ [`discount_percentage${record.key}`]: record.discount_percentage });
      form.setFieldsValue({ [`sale_discount${record.key}`]: record.sale_discount });
      form.setFieldsValue({ [`tax_percentage${record.key}`]: record.tax_percentage });
      form.setFieldsValue({ [`tax_cal_amt${record.key}`]: record.tax_cal_amt });
      form.setFieldsValue({ [`item_cal_total_amt${record.key}`]: record.item_cal_total_amt });
    });

    form.setFieldsValue({ [`qty_total`]: tableSecondaryData[0].qty_total });
    form.setFieldsValue({ [`discount_total`]: tableSecondaryData[0].discount_total });
    form.setFieldsValue({ [`tax_total`]: tableSecondaryData[0].tax_total });
    form.setFieldsValue({ [`grand_total`]: tableSecondaryData[0].grand_total });
    form.setFieldsValue({ [`sub_total`]: tableSecondaryData[0].sub_total });

    form.setFieldsValue({ "round_off_value": tableSecondaryData[0].grand_total });
    form.setFieldsValue({ "balance": tableSecondaryData[0].grand_total });

    setWithOutDecimal(tableSecondaryData[0].grand_total);
  }, [tableData])

  useEffect(() => {
    form.setFieldsValue({invoice_no:invoiceNumber})
}, [invoiceNumber])

  // --------------------- Round Off Checked  -----------------
  useEffect(() => {
    console.log('called', withDecimal, roundDecimalValue)
    const totalAmt = tableSecondaryData[0].grand_total - roundDecimalValue;
    console.log(totalAmt, 'totalAmt')
    if (round) {
      if (balance) {
        form.setFieldsValue({ round_off_value: roundDecimalValue });
        // form.setFieldsValue({ sub_total: totalAmt });
        form.setFieldsValue({ balance: 0 });
        // form.setFieldsValue({ grand_total: '1111110' });
        form.setFieldsValue({ received_amt: totalAmt });
        setBalanceChangeAmount(totalAmt);
      }
      else {
        form.setFieldsValue({ round_off_value: roundDecimalValue });
        form.setFieldsValue({ sub_total: totalAmt });
        form.setFieldsValue({ balance: totalAmt });
        form.setFieldsValue({ received_amt: 0 });
        setBalanceChangeAmount(0);
      }
    }
    else {
      if (balance) {
        form.setFieldsValue({ round_off_value: '' });
        form.setFieldsValue({ sub_total: tableSecondaryData[0].grand_total });
        form.setFieldsValue({ balance: 0 });
        form.setFieldsValue({ received_amt: tableSecondaryData[0].grand_total });
        setBalanceChangeAmount(tableSecondaryData[0].grand_total);
      }
      else {
        form.setFieldsValue({ round_off_value: '' });
        form.setFieldsValue({ sub_total: tableSecondaryData[0].grand_total });
        form.setFieldsValue({ balance: tableSecondaryData[0].grand_total });
        form.setFieldsValue({ received_amt: 0 });
        setBalanceChangeAmount(0);
      }
    }

  }, [round])

  const BalanceOnChange = (value) => {
    setBalanceChangeAmount(value)
  }

  useEffect(() => {
    // const WithoutDecimal = tableSecondaryData[0].grand_total - roundDecimalValue;
    // const totalAmt = tableSecondaryData[0].grand_total;

    if (round) {
      if (balance) {
        form.setFieldsValue({ received_amt: withDecimal });
        form.setFieldsValue({ balance: 0 });
        setBalanceChangeAmount(withDecimal);
      }
      else {
        form.setFieldsValue({ received_amt: 0 });
        form.setFieldsValue({ balance: withDecimal });
        setBalanceChangeAmount(0);

      }
    }
    else {
      if (balance) {
        form.setFieldsValue({ received_amt: withOutDecimal });
        form.setFieldsValue({ balance: 0 });
        setBalanceChangeAmount(withOutDecimal);
      }
      else {
        form.setFieldsValue({ received_amt: 0 });
        form.setFieldsValue({ balance: withOutDecimal });
        setBalanceChangeAmount(0);
      }
    }
  }, [balance])

  useEffect(() => {

    let fizedAmount = 0;

    if (round) {
      fizedAmount = withDecimal;

      if (balance) {
        form.setFieldsValue({ received_amt: withDecimal });
        form.setFieldsValue({ balance: 0 });
        setBalanceChange(false);
      }
      else {
        // ===
        let setAmt = balanceChangeAmount;
        let balSetAmt = withDecimal - setAmt;
        console.log(setAmt, 'large5555555555555555')

        if (balSetAmt < 0) {
          setBalanceChange(true);
        }
        else {
          setBalanceChange(false);
        }
        form.setFieldsValue({ received_amt: setAmt });
        form.setFieldsValue({ balance: balSetAmt });
      }
    }
    else {
      fizedAmount = withOutDecimal;
      if (balance) {
        form.setFieldsValue({ received_amt: withOutDecimal });
        form.setFieldsValue({ balance: 0 });
        setBalanceChange(false);
      }
      else {
        // ===
        let setAmt = balanceChangeAmount;
        let balSetAmt = withOutDecimal - setAmt;
        console.log(setAmt, 'large5555555555555555')

        if (balSetAmt < 0) {
          setBalanceChange(true);
        }
        else {
          setBalanceChange(false);
        }

        form.setFieldsValue({ received_amt: setAmt });
        form.setFieldsValue({ balance: balSetAmt });
      }
    }

    console.log(fizedAmount, 'ffffffffff')
    console.log(balanceChangeAmount, 'ccccccccccccjjjjjj')

  }, [balanceChangeAmount])




  // +++++++++++++++++++++   Use Effects End +++++++++++++++++++
  // ===============  Hidden Table Data End ==================

  // ===============  Table Data Start ==================

  const columns = [
    {
      title: '#',
      render: (text, record, index) => {

        return (
          (
            <Flex alignCenter gap={'20px'} style={{ alignItems: 'center' }}>
              <h4>{index + 1}</h4>
              <DeleteButtonWrapper>
                <Button
                  style={{
                    display: 'flex',
                    padding: '10px',
                    height: 'auto',
                    fontSize: '16px',
                  }}
                  htmlType="button"
                  danger
                  onClick={() => onDelete(record.key)}
                >
                  <DeleteOutlined />
                </Button>
              </DeleteButtonWrapper>
            </Flex>
          )
        );
      },
    },
    {
      title: 'Product',
      // dataIndex: 'product',
      dataIndex: 'sales',
      key: 'sales',
      render: (text, record) => {
        return (
          <Select rules={[
            {
              required: true,
              message: 'This is a required field'
            },
          ]}
            minWidth={'150px'}
            showSearch
            name={`sales${record.key}`}
            // options={itemDetails}
            options={itemDetails}
            onChange={(value) => handleOnChangeProduct(value, record)}
            // onChange={(value) => handleOnChangeProduct(value, record)}
          />
        )
      }
    },
    {
      title: 'HSN Code',
      // dataIndex: 'hsn_code',
      dataIndex: 'item_hsn',
      key: 'item_hsn',
      render: (text, record) => {
        return (
          <Input
            minWidth={'150px'}
            name={`item_hsn${record.key}`}
            disabled
          />
        )
      }
    },
    {
      title: 'Qty',
      // dataIndex: 'qty',
      dataIndex: 'quantity',
      key: 'quantity',
      render: (text, record) => {
        return (
          <CustomInputNumber precision={2} rules={[
            {
              required: true,
              message: 'This is a required field'
            },
          ]}
            type={"text"}
            step={"0.01"}
            placed={'end'}
            minWidth={'150px'}
            min={1.00}
            name={`quantity${record.key}`}
            onChange={(value) => handleOnChangeQuantity(value, record)}
          />
        )
      }
    },
    {
      title: 'Unit',
      dataIndex: 'unit',
      render: (text, record) => (
        <CustomInputNumber precision={2} disabled
          minWidth={'150px'}
          min={1.00}
          placed={'end'}
          name={`quantity${record.key}`}
          onChange={(value) => handleOnChangePrice(value, record)}
        />
      )
    },
    {
      title: 'Price',
      // dataIndex: 'price',
      dataIndex: 'sale_price',
      render: (text, record) => (
        <CustomInputNumber precision={2} rules={[
          {
            required: true,
            message: 'This is a required field'
          },
        ]}
          minWidth={'150px'}
          min={1.00}
          placed={'end'}
          name={`sale_price${record.key}`}
          onChange={(value) => handleOnChangePrice(value, record)}
        />
      )
    },
    {
      title: 'Discount',
      children: [
        {
          title: '%',
          dataIndex: 'discount_percentage',
          key: 'discount_percentage',
          render: (text, record) => (
            <CustomInputNumber precision={2}
              minWidth={'150px'}
              placed={'end'}
              name={`discount_percentage${record.key}`}
              min={0.00}
              max={100.00}
              onChange={(value) => handleonChangeDiscount(value, record)}
            />
          )
        },
        {
          title: 'Amount',
          // dataIndex: 'discount_amt',
          dataIndex: 'sale_discount',
          key: 'sale_discount',
          render: (text, record) => (
            <CustomInputNumber precision={2}
              minWidth={'150px'}
              placed={'end'}
              name={`sale_discount${record.key}`}
              disabled
            // onChange={(value) => handleTotalDiscount(value, record)}
            />
          )
        },
      ],
    },
    {
      title: 'Tax',
      children: [
        {
          title: 'GST %',
          dataIndex: 'tax_percentage',
          key: 'tax_percentage',
          render: (text, record) => (
            <CustomInputNumber
              minWidth={'150px'}
              placed={'end'}
              name={`tax_percentage${record.key}`}
              min={1}
              max={100}
              precision={0}
              rules={[
                {
                  required: true,
                  message: 'This is a required field'
                },
              ]}
              onChange={(value) => handleOnChangeTax(value, record)}
            />
          )
        },
        {
          title: 'Amount',
          // dataIndex: 'tax_amt',
          dataIndex: 'tax_cal_amt',
          key: 'tax_cal_amt',
          render: (text, record) => (
            <CustomInputNumber
              minWidth={'150px'}
              disabled
              placed={'end'}
              name={`tax_cal_amt${record.key}`}
            />
          )
        },
      ],
    },
    {
      title: (
        <p>Amount</p>
      ),
      // dataIndex: 'amount',
      dataIndex: 'item_cal_total_amt',
      key: 'item_cal_total_amt',
      render: (text, record) => (
        <CustomInputNumber precision={2}
          disabled
          minWidth={'150px'}
          placed={'end'}
          name={`item_cal_total_amt${record.key}`}
        />
      )
    },
  ]

  // ===============  Table Data End ==================


  // ==================  Table Functions Start ==================

  // ----------------- Add Row Function 

  const AddRow = () => {
    const newData = {
      key: count,
      sales: '',
      // itemCode: '',
      item_hsn: '',
      description: '',
      quantity: '',
      unit: '',
      sale_price: '',
      discount_percentage: '',
      sale_discount: '',
      tax_percentage: '',
      tax_cal_amt: '',
      item_cal_total_amt: '',
    };
    setTableData(pre => {
      return [...pre, newData]
    })
    setCount(count + 1);
  }

  // -----------------------  Delete Row Function

  const onDelete = (key) => {
    if (tableData.length > 1) {
      setTableData(prevState => {
        const newData = prevState.filter(item => item.key !== key);

        // ------ Variables 
        let totalQuantity = 0;
        let totalDiscount = 0;
        let totalTax = 0;
        let totalAmount = 0;

        newData.forEach(item => {
          if (item.quantity !== '' || item.item_cal_total_amt !== '' || item.sale_discount !== '' || item.tax_cal_amt !== '') {
            totalQuantity += parseFloat(item.quantity);
            totalDiscount += parseFloat(item.sale_discount);
            totalTax += parseFloat(item.tax_cal_amt);
            totalAmount += parseFloat(item.item_cal_total_amt);
          }
        });

        // update the grand_total value in the tableSecondaryData array
        setTableSecondaryData([{
          qty_total: totalQuantity.toFixed(2),
          discount_total: totalDiscount.toFixed(2),
          tax_total: totalTax.toFixed(2),
          grand_total: totalAmount.toFixed(2)
        }]);

        // setTableFooterData

        return newData;
      });
    } else {
      console.log(`only ${tableData.length} is available`)
    }
  };

  // ========================   Total Calculating Functions
  // ----------------- 1. Calculate TotalAmount 

  const CalculateTotal = (record) => {

    console.log(record, 'record')
    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];
      item.item_cal_total_amt = record.item_cal_total_amt || 0;
      item.tax_cal_amt = record.tax_cal_amt || 0;
      item.quantity = record.quantity || 0;
      item.sale_discount = record.sale_discount || 0;
      // item.tax_cal_amt = value || 0;

      // ------ Variables 
      let totalQuantity = 0;
      let totalDiscount = 0;
      let totalTax = 0;
      let totalAmount = 0;

      newData.forEach(item => {
        if (item.quantity !== '' || item.item_cal_total_amt !== '' || item.sale_discount !== '' || item.tax_cal_amt !== '') {
          totalQuantity += parseFloat(item.quantity);
          totalDiscount += parseFloat(item.sale_discount);
          totalTax += parseFloat(item.tax_cal_amt);
          totalAmount += parseFloat(item.item_cal_total_amt);
        }
      });

      // update the grand_total value in the tableSecondaryData array
      setTableSecondaryData([{
        qty_total: totalQuantity.toFixed(2),
        discount_total: totalDiscount.toFixed(2),
        tax_total: totalTax.toFixed(2),
        grand_total: totalAmount.toFixed(2)
      }]);

      return newData;
    })
  };

  // ============  OnChange Functions  ==============

  const HandleQty = (value, record) => {
    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];
      item.quantity = value || 0;
      item.sale_price = record.sale_price || 0;
      item.discount_percentage = record.discount_percentage;

      let CalAmount = 0;

      if (item.discount_percentage != 0) {
        const Amt = calculateAmount(item);
        item.sale_discount = (Amt * item.discount_percentage) / 100;
        CalAmount = Amt - item.sale_discount;
      } else {
        CalAmount = calculateAmount(item);
      }

      item.amount = CalAmount;

      HandlePrice(item.sale_price, {
        ...item,
        quantity: item.quantity,
        item_cal_total_amt: CalAmount,
        sale_price: item.sale_price,
      })

      CalculateTotal({
        ...item,
        quantity: item.quantity,
        item_cal_total_amt: CalAmount,
        sale_price: item.sale_price,
      })

      HandleTax(item.tax_percentage, {
        ...item,
        quantity: item.quantity,
        item_cal_total_amt: CalAmount,
        sale_price: item.sale_price,
      })

      return newData;
    });
  }

  const HandlePrice = (value, record) => {
    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];

      item.quantity = record.quantity || 0;
      item.sale_price = value || 0;
      item.discount_percentage = record.discount_percentage;

      // const amount = sale_price + tax_cal_amt;
      let CalAmount = 0;

      if (item.discount_percentage != 0) {
        const Amt = calculateAmount(item);
        item.sale_discount = (Amt * item.discount_percentage) / 100;
        CalAmount = Amt - item.sale_discount;
      } else {
        CalAmount = calculateAmount(item);
      }
      item.item_cal_total_amt = CalAmount;

      CalculateTotal({
        ...item,
        quantity: item.quantity,
        sale_price: item.sale_price,
        item_cal_total_amt: CalAmount,
      })

      HandleTax(item.tax_percentage, {
        ...item,
        quantity: item.quantity,
        item_cal_total_amt: CalAmount,
        sale_price: item.sale_price,
      })

      return newData;
    });
  }

  const HandleDiscount = (value, record) => {
    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];

      const Qty = record.quantity || 0;
      const sale_price = record.sale_price || 0;
      const DiscountPercentage = value || 0;
      const TaxPercentage = record.tax_percentage || 0;

      const MultiplyAmount = calculateAmount(item);

      let Amt = 0;

      if (TaxPercentage != 0) {
        if (DiscountPercentage != 0) {
          const OriginalAmount = calculateAmount(item);
          const DisMinus = (OriginalAmount * DiscountPercentage) / 100;

          const ApplyDiscount = OriginalAmount - DisMinus;

          const taxAmt = (ApplyDiscount * TaxPercentage) / 100;
          const ApplyTax = ApplyDiscount + taxAmt

          item.discount_percentage = DiscountPercentage;
          item.sale_discount = DisMinus;
          item.tax_percentage = TaxPercentage;
          item.tax_cal_amt = taxAmt;
          Amt = ApplyTax;

          CalculateTotal({
            ...item,
            sale_discount: item.sale_discount,
            item_cal_total_amt: Amt,
          })
        }
        else {
          const OriginalAmount = calculateAmount(item);
          const TaxPlus = (OriginalAmount * TaxPercentage) / 100;

          const ApplyTax = OriginalAmount + TaxPlus;

          item.tax_percentage = TaxPercentage;
          item.tax_cal_amt = TaxPlus;
          item.sale_discount = 0;
          Amt = ApplyTax;

          CalculateTotal({
            ...item,
            sale_discount: item.sale_discount,
            item_cal_total_amt: Amt,
          })
        }
      }
      else {
        if (DiscountPercentage != 0) {

          const OriginalAmount = calculateAmount(item);
          const DisMinus = (OriginalAmount * DiscountPercentage) / 100;

          const ApplyDiscount = OriginalAmount - DisMinus;
          item.discount_percentage = DiscountPercentage;
          item.sale_discount = DisMinus;
          item.discount_percentage = 0;
          Amt = ApplyDiscount;

          CalculateTotal({
            ...item,
            sale_discount: item.sale_discount,
            item_cal_total_amt: Amt,
          })
        }
        else {
          const OriginalAmount = calculateAmount(item);
          item.sale_discount = 0;

          Amt = OriginalAmount;

          CalculateTotal({
            ...item,
            sale_discount: item.sale_discount,
            item_cal_total_amt: Amt,
          })
        }
      }

      item.item_cal_total_amt = Amt;
      item.discount_percentage = DiscountPercentage;

      return newData;
    })
  }

  const HandleProduct = (value, record) => {
    // setTableData(prevState => {
    //   const newData = [...prevState];
    //   const index = newData.findIndex(item => record.key === item.key);
    //   const item = newData[index];
    //   item.sales = value;

    //   return newData;
    // });
   

    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];
      item.sales = value;
      const setSelectedSale = getdata.find(item => item.id === value);
      item.item_hsn = setSelectedSale.item_hsn;
      item.unit = setSelectedSale.item_unit;
     
      return newData;
    });
  }

  const HandleTax = (value, record) => {
    console.log(value, record, 'HandleTax')
    setTableData(prevState => {
      const newData = [...prevState];
      const index = newData.findIndex(item => record.key === item.key);
      const item = newData[index];

      const Qty = record.quantity || 0;
      const sale_price = record.sale_price || 0;
      const DiscountPercentage = record.discount_percentage || 0;
      const TaxPercentage = value || 0;

      const MultiplyAmount = calculateAmount(item);

      let Amt = 0;

      if (TaxPercentage != 0) {
        if (DiscountPercentage != 0) {
          const OriginalAmount = calculateAmount(item);
          const DisMinus = (OriginalAmount * DiscountPercentage) / 100;

          const ApplyDiscount = OriginalAmount - DisMinus;

          const taxAmt = (ApplyDiscount * TaxPercentage) / 100;
          const ApplyTax = ApplyDiscount + taxAmt

          item.discount_percentage = DiscountPercentage;
          item.sale_discount = DisMinus;
          item.tax_percentage = TaxPercentage;
          item.tax_cal_amt = taxAmt;
          Amt = ApplyTax;

          CalculateTotal({
            ...item,
            tax_cal_amt: item.tax_cal_amt,
            item_cal_total_amt: Amt,
          })
        }
        else {
          const OriginalAmount = calculateAmount(item);
          const TaxPlus = (OriginalAmount * TaxPercentage) / 100;

          const ApplyTax = OriginalAmount + TaxPlus;

          item.tax_percentage = TaxPercentage;
          item.tax_cal_amt = TaxPlus;
          Amt = ApplyTax;

          CalculateTotal({
            ...item,
            tax_cal_amt: item.tax_cal_amt,
            item_cal_total_amt: Amt,
          })
        }
      }
      else {
        if (DiscountPercentage != 0) {

          const OriginalAmount = calculateAmount(item);
          const DisMinus = (OriginalAmount * DiscountPercentage) / 100;

          const ApplyDiscount = OriginalAmount - DisMinus;

          // const taxAmt = (ApplyDiscount * TaxPercentage) / 100;
          // const ApplyTax = ApplyDiscount + taxAmt

          item.discount_percentage = DiscountPercentage;
          item.sale_discount = DisMinus;
          item.tax_cal_amt = 0;
          Amt = ApplyDiscount;

          CalculateTotal({
            ...item,
            tax_cal_amt: item.tax_cal_amt,
            item_cal_total_amt: Amt,
          })
        }
        else {
          const OriginalAmount = calculateAmount(item);
          item.tax_cal_amt = 0;

          Amt = OriginalAmount;

          CalculateTotal({
            ...item,
            tax_cal_amt: item.tax_cal_amt,
            item_cal_total_amt: Amt,
          })
        }
      }

      item.item_cal_total_amt = Amt;
      item.tax_percentage = TaxPercentage;

      return newData;
    })
  }

  // ---------------- 1.TotalQuantity ONCHANGE Function

  const handleOnChangeQuantity = (value, record) => {
    HandleQty(value, record)
  }

  const handleOnChangePrice = (value, record) => {
    HandlePrice(value, record)
  }

  const handleonChangeDiscount = (value, record) => {
    HandleDiscount(value, record)
  }

  const itemDetails = getdata.map(item => ({ label: item.item_name, value: item.id }));

  console.log(itemDetails,'ddd')

  const handleOnChangeProduct = (value, record) => {
    HandleProduct(value, record)
  }


  const handleOnChangeTax = (value, record) => {
    HandleTax(value, record)
  }


  // -------------- Handle Total Row Amount  --------------
  const calculateAmount = (record) => {
    const quantity = parseFloat(record.quantity) || 0;
    const sale_price = parseFloat(record.sale_price) || 0;
    return quantity * sale_price;
  }

  //  ======================  Other Functions =========

  // ====================  On Finish Function ============

  const onFinish = (values) => {
    const record = { ...values, invoice_date: selectedDate };
    console.log(values, 'success')
    AddSale(record)
    // setSale(record)

    let result = {
      payment_type: record.payment_type,
      reference_no: record.reference_no,
      credit_period: record.credit_period,
      qty_total: record.qty_total,
      discount_total: record.discount_total,
      tax_total: record.tax_total,
      GSTIN: record.GSTIN,
      grand_total: record.grand_total,
      old_balance: record.old_balance,
      advanced_amt: record.advanced_amt,
      round_off: record.round_off,
      round_off_value: record.round_off_value,
      recevied_status: record.recevied_status,
      received_amt: record.received_amt,
      balance: record.balance,
      invoice_date: record.invoice_date,
      invoice_no: record.invoice_no,
      mobile_number: record.mobile_number,
      customer_name: record.customer_name,
      company_name: record.company_name,

      sales: Object.entries(record)
        .filter(([key]) => key.startsWith('sales'))
        .map(([key, sales]) => {
          const index = key.slice(-1);

          // const itemkey = `itemCode${index}`;
          const hsnKey = `item_hsn${index}`;
          const quantityKey = `quantity${index}`;
          const unitKey = `unit${index}`;
          const saleKey = `sale_price${index}`;
          const discountPercentageKey = `discount_percentage${index}`;
          const saleamtKey = `sale_discount${index}`;
          const taxPercentageKey = `tax_percentage${index}`;
          const taxamyKey = `tax_cal_amt${index}`;
          const totaltaxantKey = `item_cal_total_amt${index}`;
          return {
            sales,
            // itemCode: record[itemkey],
            item_hsn: record[hsnKey],
            quantity: record[quantityKey],
            unit: record[unitKey],
            sale_price: record[saleKey],
            discount_percentage: record[discountPercentageKey],
            sale_discount: record[saleamtKey],
            tax_percentage: record[taxPercentageKey],
            tax_cal_amt: record[taxamyKey],
            item_cal_total_amt: record[totaltaxantKey],
          };
        }),
    };
    console.log(result, 'check')







    // var val = ''
    // if (state === false) {
    //   val = 'credit'
    // }
    // else (
    //   val = 'cash'
    // )

    // const data = { ...values, switch: val }
    // const my_arr = []

    // for (var i = 1; i <= tableData.length; i++) {
    //   const FilteredData = Object.fromEntries(Object.entries(values).filter(([key]) => key.includes(i)));

    //   const item = FilteredData[`item${i}`];
    //   const quantity = FilteredData[`quantity${i}`];
    //   const sale_price = FilteredData[`sale_price${i}`];
    //   const discount_percentage = FilteredData[`discount_percentage${i}`];
    //   const sale_discount = FilteredData[`sale_discount${i}`];
    //   const tax_percentage = FilteredData[`tax_percentage${i}`];
    //   const tax_cal_amt = FilteredData[`tax_cal_amt${i}`];

    //   const unit = FilteredData[`unit${i}`];

    //   const my_obj = {
    //     item: item,
    //     quantity: quantity,
    //     sale_price: sale_price,
    //     unit: unit,
    //     discount_percentage: discount_percentage,
    //     sale_discount: sale_discount,
    //     tax_percentage: tax_percentage,
    //     tax_cal_amt: tax_cal_amt,
    //   }
    //   my_arr.push(my_obj)
    // }

    // const total_arry = {
    //   table_data: my_arr,
    //   img: files,
    // }
    // setFiles(null)
    // const reducedarr = [tableData[0]];
    // setTableData(reducedarr)

  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };


  // ==============  Add Row Component  ================

  const FooterComponent = () => {
    return (
      <div style={{ background: 'var(--light-color)', padding: '20px' }}>
        <Row>
          <Col lg={4} sm={12} span={24}><Button type="primary" style={{
            fontSize: '1rem',
            height: 'auto',
            fontFamily: 'Poppins',
            fontWeight: 500,
            letterSpacing: '1px',
          }}
            htmlType="button"
            onClick={AddRow}>
            Add Row
          </Button>
          </Col>
        </Row>
      </div >
    )
  }

  // ==================  Table  ==================
  const onRest = () => {
    form.resetFields();
  }
  return (
    <Fragment>
      <Form name="sales"
        labelCol={{
          span: 24,
        }}
        wrapperCol={{
          span: 24,
        }}
        form={form}
        initialValues={
          {
            invoice_date: dayjs()
          }
        }
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}>

        <SalesFormHeader setSale={setSale} setSelectedSale={setSelectedSale} setInvoiceNumber={setInvoiceNumber} />


        <div style={{ margin: '20px 0' }}>
          <Table columns={columns.filter(Boolean)} data={tableData} pagination={false} />
          <FooterComponent />
        </div>


        <div style={{ margin: '20px 0' }}>
          <SalesFormFooter BalanceOnChange={BalanceOnChange} RoundOffChecked={RoundOffChecked} TotalBalance={TotalBalance} tableSecondaryData={tableSecondaryData} footerCalData={footerCalData} setRoundDecimalValue={setRoundDecimalValue} round={round} />
        </div>

        <Card>
          <Flex flexEnd gap={'10px'}>
            <Button.Primary text={'Submit'} htmlType="submit" disabled={balanceChange} />
            <Button.Danger text={'Cancel'} onClick={onRest} htmlType="cancel" />
          </Flex>
        </Card>
      </Form>

      <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={500} modalTitle={modalTitle} modalContent={modalContent} />
    </Fragment>
  )
}