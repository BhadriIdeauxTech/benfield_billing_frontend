import { Col, Form } from 'antd'
import React, { Fragment, useEffect, useState } from 'react'
import { Row } from '../../../Components/Row';
import { CustomSelect } from '../../../Components/Form/CustomSelect';
import Input from '../../../Components/Form/Input';
import { CustomInputNumber } from '../../../Components/Form/CustomInputNumber';
import { Select } from '../../../Components/Form/Select';
import { TextAreas } from '../../../Components/Form/TextArea';
import { CustomDatePicker } from '../../../Components/Form/CustomDatePicker';
import { Modal } from '../../../Components/Modal';
import dayjs from 'dayjs';
import { phoneValidator } from '../../../utils/PhnNumberValidator'
import Button from '../../../Components/Form/Button';
import { AiOutlinePlus } from 'react-icons/ai';
import AddCustomers from '../../Customers/AddCustomers';
import { TopTitle } from '../../../Components/Form/TopTitle';
import request from '../../../utils/request';
import Flex from '../../../Components/Flex';
import AddingCustomers from '../../Customers/AddCustomers/Partials/AddCustomers';




export const SalesFormHeader = ({ setSale, setSelectedSale, setInvoiceNumber }) => {
    const [getdata, setGetdata] = useState([])

    const [form] = Form.useForm();
    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    // ======  Selected Date ========

    const onViewRow = () => {
        setModalTitle("Add Customer");
        setModalContent(<AddingCustomers handleCancel={handleCancel} />);
        showModal();
    }

    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };


    useEffect(() => {
        GetSaleCustomer();
    }, [])

    const GetSaleCustomer = () => {
        request.get('sales/get_detail_sale/')
            .then(function (response) {
                setGetdata(response.data.customer)
                setInvoiceNumber(response.data.invoice_no)
                console.log(response.data, 'sale');
                // setSale(response.data)
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    const SaleMobiles = getdata?.map(mob => ({ label: mob.mobile_number, value: mob.id }));

    const handleSelectedSale = (value) => {
        const SelectedSaleDetails = getdata.find((mem) => mem.id === value)
        setSelectedSale(SelectedSaleDetails);

    }


    // ==========  Date Change =======
    const handleOnChange = (date) => {
        // setSelectedDate(date);
    };
    const option = [
        {
            label: 'Tamil Nadu',
            value: 'TamilNadu'

        },
        {
            label: 'Kerala',
            value: 'Kerala'
        },
        {
            label: 'AndraPradesh',
            value: 'AndraPradesh'
        }
    ]

    const CusData = [
        {
            label: 'rejin',
            value: 'rejin'
        },
        {
            label: 'gladine',
            value: 'gladine'
        },
        {
            label: 'saras',
            value: 'saras'
        },
        {
            label: 'ishwarya',
            value: 'ishwarya'
        },

    ]

    return (
        <Fragment style={{ margin: '0 auto', width: '95%' }}>
            <TopTitle Heading={'Sales Page'} />
            <Row gutter={[24, 24]} style={{ backgroundColor: 'white', padding: '25px', borderRadius: '10px', boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)' }}>

                <Col span={24} md={16}>
                    <Row gutter={[12, 12]}>
                        <Col span={24} md={12}>
                            {/* <Input label={'Mobile Number'} name={'mobile_number'} 
                            onChange={handleMobileShow} 
                            placeholder={'Mobile Number'}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the mobile number !'
                                },
                                { validator: phoneValidator },
                                {
                                    max: 10,
                                    message: 'Only 10 Digit enter'
                                },
                                {
                                    min: 10,
                                    message: 'to Short'
                                }
                                ]} /> */}
                            <Select
                                options={SaleMobiles}
                                showSearch label={'Mobile Number'}
                                placeholder={'Select Number'} name={'mobile_number_id'}
                                // onChange={handleMobileShow} 
                                onChange={handleSelectedSale}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Select Mobile Number !'
                                    }
                                ]} />

                        </Col>

                        <Col span={24} md={12}>
                            <Flex center alignEnd H_100>
                                <Button.Primary shape='round' onClick={() => onViewRow()} size='large' icon={<AiOutlinePlus style={{ fontSize: '1rem', fontWeight: 1000 }} />} text={'Add Customer'} />
                            </Flex>
                        </Col>

                        <Col span={24} md={12}>
                            <Input label={'GST IN'} name={'GSTIN'} placeholder={'GST IN'} disabled />
                        </Col>

                        <Col span={24} md={12}>
                            <Input label={'Customer Name'} name={'customer_name'} placeholder={'Customer Name'} disabled rules={[{
                                required: 'true',
                                message: 'Enter the customer name !'
                            }]} />
                        </Col>

                        <Col span={24} md={12}>
                            <Input label={'Email ID'} name={'email'} placeholder={'Email ID'} disabled />
                        </Col>

                        <Col span={24} md={12}>
                            <Input label={'Company Name'} name={'company_name'} placeholder={'Company Name'} disabled />
                        </Col>

                        <Col span={24} md={12}>
                            <TextAreas label={'Address'} name={'address'} placeholder={'Address'} disabled />
                        </Col>
                        <Input name={'customer'} display={"none"} />
                        <Input name={'mobile_number'} display={"none"} />
                    </Row>
                </Col>
                <Col span={24} md={8}>
                    <Row>
                        <Col span={24} md={24}>
                            <CustomInputNumber label={'Sale Invoice Number'} name={'invoice_no'} disabled placeholder={'Invoice Number'}
                            />
                        </Col>
                        <Col span={24} md={24}>
                            <CustomDatePicker label={'Sale Date'} onChange={handleOnChange} name={'invoice_date'}
                            />
                        </Col>

                        <Col span={24} md={24}>
                            <Select label={'State'} name={'state_of_supply'} placeholder={'Select selet'} options={option}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the mobile number !'
                                },]} />
                        </Col>
                    </Row>
                </Col>

            </Row>


            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />
        </Fragment>
    )
}
