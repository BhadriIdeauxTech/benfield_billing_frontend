import React from 'react'
import { SalesEntryPage } from './Partials/SalesEntryPage'

const SalesMain = ({setSale, getSale, selectedDate}) => {
  return (
    <div>
        <SalesEntryPage setSale={setSale}  getSale={getSale} selectedDate={selectedDate}/>
    </div>
  )
}

export default SalesMain