import React from 'react'
import { TopTitle } from '../../../../Components/Form/TopTitle'
import { Table } from '../../../../Components/Table'
import { Modal } from '../../../../Components/Modal'
import Button from '../../../../Components/Form/Button'
import Flex from '../../../../Components/Flex'
import { useState } from 'react'
import { Col, Form, Modal as Modals } from 'antd';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons'
import { Row } from '../../../../Components/Row'
import Input from '../../../../Components/Form/Input'
import { TextAreas } from '../../../../Components/Form/TextArea'
import { InputNumber } from '../../../../Components/Form/InputNumber'
import { useEffect } from 'react'
import request from '../../../../utils/request'

const TableEditBusiness = () => {

    const URL = 'profile/business_view'

    const [form] = Form.useForm();

    const [selectedSupplier, setSelectedSupplier] = useState({})

    const onFinish = (values) => {
        console.log('Success:', values);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    useEffect(() => {
        GetBusines();
    }, [])

    useEffect(() => {
        form.setFieldsValue({ business_name: selectedSupplier.business_name })
        form.setFieldsValue({ email: selectedSupplier.email })
        form.setFieldsValue({ phone_no: selectedSupplier.phone_no })
        form.setFieldsValue({ phone_no2: selectedSupplier.phone_no2 })
        form.setFieldsValue({ gstin: selectedSupplier.gstin })
        form.setFieldsValue({ address: selectedSupplier.address })

    }, [selectedSupplier])

    const GetBusines = (values) => {
        request.get(`${URL}`, values)
            .then(function (response) {
                console.log(response.data, 'business');
                setSelectedSupplier(response.data)
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    console.log(selectedSupplier,'rrrrrrrreee')

    return (

        <Form
            form={form}
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off">
            <Row gutter={[24, 24]}>
                <Col span={24} md={12}>
                    <Input label={'Business Name'} placeholder={'Enter Your Business'} disabled 
                    name={'business_name'}
                    />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'EmailID'} name={'email'} disabled placeholder={"Enter Your Mail ID"}
                    />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'Phone No 1'} name={'phone_no'} disabled placeholder={"Enter Your Phonenum 1"}
                    />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'Phone No 2'} name={'phone_no2'} disabled placeholder={"Enter Your Phonenum 2"} />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'GSTIN'} placeholder={'Enter Your GSTIN'} disabled name={'gstin'}
                    />
                </Col>
                <Col span={24} md={12}>
                    <TextAreas label={'Address'} name={'address'} disabled placeholder={"Enter Your Address"}
                    />
                </Col>
            </Row>
        </Form>

    )
}

export default TableEditBusiness