import React from 'react'
import BusinessProfile from './Partials/BusinessProfile'
import { TopTitle } from '../../../Components/Form/TopTitle'
import { CustomCard } from '../../../Components/CustomCard'

const BusinessProfiles = () => {
  return (
    <div>
      <TopTitle Heading={'Business Profiles'} />

      <CustomCard width={'95%'}>
        <BusinessProfile />
      </CustomCard>
    </div>
  )
}

export default BusinessProfiles