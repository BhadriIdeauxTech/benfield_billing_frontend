import { Col, Form } from "antd";
import { Row } from "../../../../Components/Row";
import Input from "../../../../Components/Form/Input";
import Flex from "../../../../Components/Flex";
import Button from "../../../../Components/Form/Button";
import { InputNumber } from "../../../../Components/Form/InputNumber";
import { TextAreas } from "../../../../Components/Form/TextArea";
import { TopTitle } from "../../../../Components/Form/TopTitle";
import { CustomInputNumber } from "../../../../Components/Form/CustomInputNumber";
import request from "../../../../utils/request";


const BusinessProfile = ({ setMembers }) => {
    const [form] = Form.useForm();

    const URL = 'profile/business_view'

    // const member = useSelector(state=>state);
    // console.log(member)

    const onFinish = (values) => {
        Addbusiness(values)
        // setMembers(values)
        console.log('Success:', values);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const Addbusiness = (values) => {
        request.post(`${URL}`, values)
            .then(function (response) {
                console.log(response);
                // setMembers(values)
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    const onReset = () => {
        form.resetFields();
    }
    // const option = [
    //     { label: 'Admin', value: 'admin' },
    //     { label: 'GST Admin', value: 'gst_admin' },
    //     { label: 'GST Biller', value: 'gst_biller' },
    //     { label: 'Non GST Admin', value: 'non_gst_admin' },
    //     { label: 'Non GST Biller', value: 'non_gst_biller' },
    // ]
    return (
        <Form
            form={form}
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off">

            <Row gutter={[24, 24]}>
                <Col span={24} md={12}>
                    <Input label={'Business Name'} placeholder={'Enter Your Business'} name={'business_name'} rules={[
                        {
                            required: true,
                            message: 'Please Enter Your Business!',
                        }
                    ]} />
                </Col>

                <Col span={24} md={12}>
                    <Input label={'EmailID'} name={'email'} placeholder={"Enter Your Mail ID"}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Your Phone Number!',
                            }
                        ]} />
                </Col>

                <Col span={24} md={12}>
                    <CustomInputNumber label={'Phone No 1'} name={'phone_no'} placeholder={"Enter Your Phonenum 1"}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Your Phone Number!',
                            }
                        ]} />
                </Col>

                <Col span={24} md={12}>
                    <CustomInputNumber label={'Phone No 2'} name={'phone_no2'} placeholder={"Enter Your Phonenum 2"} />
                </Col>

                <Col span={24} md={12}>
                    <Input label={'GSTIN'} placeholder={'Enter Your GSTIN'} name={'gstin'} rules={[
                        {
                            required: true,
                            message: 'Please Enter GSTIN !',
                        }
                    ]} />
                </Col>

                <Col span={24} md={12}>
                    <TextAreas label={'Address'} name={'address'} placeholder={"Enter Your Address"} rules={[
                        {
                            required: true,
                            message: 'Please Enter Your Address!',
                        }
                    ]} />
                </Col>

                <Flex center gap={'20px'} style={{ margin: '25px 500px 0px 0px' }}>
                    <Button.Primary text={'SAVE'} htmlType={'submit'} />
                    <Button.Danger text={'RESET'} htmlType={'cancel'} onClick={() => onReset()} />
                </Flex>
            </Row>

        </Form>
    )
}

export default BusinessProfile