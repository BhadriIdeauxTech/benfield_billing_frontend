import { Col, Form } from 'antd'
import React, { Fragment, useState } from 'react'
import { Row } from '../../../Components/Row';
import { CustomSelect } from '../../../Components/Form/CustomSelect';
import Input from '../../../Components/Form/Input';
import { CustomInputNumber } from '../../../Components/Form/CustomInputNumber';
import { Select } from '../../../Components/Form/Select';
import { TextAreas } from '../../../Components/Form/TextArea';
import { CustomDatePicker } from '../../../Components/Form/CustomDatePicker';
import { Modal } from '../../../Components/Modal';
import dayjs from 'dayjs';
import { phoneValidator } from '../../../utils/PhnNumberValidator'
import Button from '../../../Components/Form/Button';
import { AiOutlinePlus } from 'react-icons/ai';
import AddCustomers from '../../Customers/AddCustomers';
import { TopTitle } from '../../../Components/Form/TopTitle';




export const SalesFormHeader = ({ setSaleorder }) => {
    const [form] = Form.useForm();
    const [mobileshow, setMobileshow] = useState(false)
    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    // ======  Selected Date ========
    const [selectedDate, setSelectedDate] = useState(dayjs().format('MMMM DD, YYYY'));

    const handleMobileShow = () => {
        setMobileshow(!mobileshow)
    }
    const onViewRow = () => {
        // setModalTitle("Add Details");
        setModalContent(<AddCustomers />);
        showModal();
    }

    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };

    // ==========  Date Change =======
    const handleOnChange = (date) => {
        setSelectedDate(date);
    };
    const option = [
        {
            label: 'Tamil Nadu',
            value: 'TamilNadu'

        },
        {
            label: 'Kerala',
            value: 'Kerala'
        },
        {
            label: 'AndraPradesh',
            value: 'AndraPradesh'
        }
    ]

    const CusData = [
        {
            label: 'rejin',
            value: 'rejin'
        },
        {
            label: 'gladine',
            value: 'gladine'
        },
        {
            label: 'saras',
            value: 'saras'
        },
        {
            label: 'ishwarya',
            value: 'ishwarya'
        },

    ]
    const onFinish = (values) => {
        const record = { ...values, selected_date: selectedDate };
        setSaleorder(record)
        console.log('Success:', values);
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };



    return (
        <Fragment style={{ margin: '0 auto', width: '95%' }}>
            <TopTitle Heading={'Sales Return'} />
            <Row gutter={[24, 24]} style={{ backgroundColor: 'white', padding: '25px', borderRadius: '10px', boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)' }}>
                <Col span={24} md={16}>
                    <Row gutter={[12, 12]}>
                        <Col span={24} md={12}>
                            <Input label={'Mobile Number'} name={'mobile_number'} onChange={handleMobileShow} placeholder={'Mobile Number'}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the mobile number !'
                                },
                                { validator: phoneValidator },
                                {
                                    max: 10,
                                    message: 'Only 10 Digit enter'
                                },
                                {
                                    min: 10,
                                    message: 'to Short'
                                }
                                ]} />
                        </Col>

                        {mobileshow ?
                            (
                                <>
                                    <Col span={24} md={12}>
                                        <Input label={'Customer Name'} name={'customer_name'} placeholder={'Customer Name'} rules={[{
                                            required: 'true',
                                            message: 'Enter the customer name !'
                                        }]} />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <Input label={'Company Name'} name={'company_name'} placeholder={'Company Name'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the details !'
                                            }]} />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <Input label={'GST IN'} name={'gstin'} placeholder={'GST IN'} rules={[{
                                            required: 'true',
                                            message: 'Enter the GST IN !'
                                        }]} />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <TextAreas label={'Address'} name={'address'} placeholder={'Address'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the details !'
                                            }]}
                                        />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <Input label={'Email ID'} name={'email_id'} placeholder={'Email ID'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the details!'
                                            }]} />

                                    </Col>

                                </>
                            )
                            : <Col span={24} md={24}>
                                <Button.Primary shape='round' onClick={() => onViewRow()} size='large' icon={<AiOutlinePlus style={{ fontSize: '1rem', fontWeight: 1000 }} />} text={'Add Customer'} />
                            </Col>}
                    </Row>
                </Col>
                <Col span={24} md={8}>
                    <Row gutter={[12, 12]}>
                        <Col span={24} md={24}>
                            <CustomInputNumber label={'Return Number'} name={'return_number'} placeholder={'Return Number'} disabled />
                        </Col>
                        <Col span={24} md={24}>
                            <CustomInputNumber label={'Invoice Number'} name={'invoive_number'} placeholder={'Invoice Number'} disabled />
                        </Col>
                        <Col span={24} md={24}>
                            <Input label={'Invoice Date'} name={'invoive_date'} placeholder={'Invoice date'} disabled />
                        </Col>
                        <Col span={24} md={24}>
                            <CustomDatePicker label={'Return Date'} name={'selected_date'} onChange={handleOnChange} />
                        </Col>
                        <Col span={24} md={24}>
                            <Select label={'State'} name={'state'} options={option} placeholder={'select'}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the details!'
                                }]} />
                        </Col>
                    </Row>
                </Col>

            </Row>

            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />
        </Fragment>
    )
}
