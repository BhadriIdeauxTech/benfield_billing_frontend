import { Card, Col, Form } from 'antd'
import React, { Fragment } from 'react'
import { Row } from '../../../Components/Row'
import { CustomSelect } from '../../../Components/Form/CustomSelect'
import { TextAreas } from '../../../Components/Form/TextArea'
import { CustomInputNumber } from '../../../Components/Form/CustomInputNumber'
import Checkbox from '../../../Components/Form/Checkbox'
import Flex from '../../../Components/Flex'
import { useState } from 'react'
import { Select } from '../../../Components/Form/Select'
import Switch from '../../../Components/Form/Switch'
import Label from '../../../Components/Form/Label'



export const SalesFormFooter = ({ BalanceOnChange, setReceivedRow, TotalBalance, setRoundDecimalValue, RoundOffChecked, round, footerCalData, setSaleorder, tableSecondaryData }) => {
    const [switched, setSwitched] = useState(false);
    const onhandleSwitch = () => {
        setSwitched(!switched);
    }
    const CusData = [
        {
            label: 'Cash',
            value: 'Cash'
        },
        {
            label: 'Check',
            value: 'Check'
        },
        {
            label: 'Online Transaction',
            value: 'Online Transaction'
        },
    ]
    const [payType, setPayType] = useState('');

    const handleSelectChange = (values) => {
        setPayType(values);
    }

    const handleRoundChecked = (e) => {
        RoundOffChecked(e.target.checked)
        const num = tableSecondaryData[0].total_amount;
        const newInteger = parseInt(num);
        const newDecimal = (num - newInteger).toFixed(2).substr(1);
        setRoundDecimalValue(newDecimal);
    }

    const balanceCheck = (e) => {
        TotalBalance(e.target.checked)
    }

    const decimalNumber = (e) => {
        const datas = footerCalData;
    }

    const Cheque = [

        { label: 'Cash', value: 'suplier_credit_payment' },
        { label: 'Cheque', value: 'suplier_advance_payment' },
        { label: 'UPI', value: 'suplier_debit_amount' },
    ]

    const HandleOnchange = (val) => {
        console.log(val, 'vvvvvvvvvvvvv');
        BalanceOnChange(val)
    }

    return (
        <Fragment>
            <Row gutter={[24, 24]} >
                <Col lg={10} md={12} span={24}>
                    <Row gutter={[12, 12]} style={{ backgroundColor: 'white', padding: '15px', borderRadius: '6px' }}>
                        <Col span={24} md={20} >
                            <Select options={Cheque} label={'Payment type '} defaultValue={'Cash'} placeholder={'Select Payement Type'} onChange={handleSelectChange} name={'supplier_pay_type'} rules={[
                                {
                                    required: true,
                                    message: 'Select the payment type !'
                                }
                            ]} /></Col>
                        <Col span={24} md={20} >
                            {/* Supplier Advanced Payment */}
                            {payType === 'suplier_advance_payment' && (
                                <div>
                                    <CustomInputNumber label={'Ref No.'} placeholder={'Reference Number'} name={'refno'} rules={[
                                        {
                                            required: true,
                                            message: 'Enter the Ref no!'
                                        }
                                    ]} />
                                </div>
                            )}
                        </Col>
                        {/* Supplier Credit Payment */}
                        <Col span={24} md={24}></Col>
                    </Row>
                </Col>

                <Col lg={4} md={0} span={0}></Col>

                <Col lg={10} md={12} span={24}>
                    <Card>
                        <Row gutter={[12, 12]}>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Quantity'}
                                    name={'total_qty'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Discount'}
                                    name={'total_discount'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Tax'}
                                    name={'total_tax'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Amount'}
                                    name={'total_amount'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                        </Row>
                    </Card>
                </Col>

                <Col lg={10} md={4} span={0}>
                    <Row gutter={[12, 12]} style={{ backgroundColor: 'white', padding: '15px', borderRadius: '6px' }}>
                        <Col span={24} lg={20}>
                            <CustomInputNumber precision={2}
                                label={'Cutomer Credit'}
                                name={'cutomer_credit'}
                                // placed={'end'}
                                disabled
                            />
                        </Col>
                        <Col span={24} lg={20}>
                            <CustomInputNumber precision={2}
                                label={'Cutomer Debit'}
                                name={'cutomer_debit'}
                                // placed={'end'}
                                disabled
                            />
                        </Col>
                        <Col span={24} lg={20}>
                            <CustomInputNumber precision={2}
                                label={'Cutomer Advanced'}
                                name={'cutomer_advanced'}
                                // placed={'end'}
                                disabled
                            />
                        </Col>
                    </Row>
                </Col>

                <Col lg={14} md={20} span={24}>
                    <Row gutter={[12, 12]}>
                        <Col span={24}>
                            <Row gutter={[12, 12]}>
                                <Col sm={12} span={24} style={{
                                    display: 'flex',
                                    alignItems: 'end',
                                }}>
                                    <Row gutter={[12, 12]}>
                                        <Col lg={16} span={12}>
                                            <Checkbox label={'Round Off'} onChange={handleRoundChecked} />
                                        </Col>

                                        <Col lg={8} span={12}>
                                            <CustomInputNumber precision={2} name={'round_off'} placed={'end'} disabled />
                                        </Col>
                                    </Row>
                                </Col>

                                <Col sm={12} span={24}>
                                    <CustomInputNumber precision={2} name={'roundoff_amount'} label={'Total'} placed={'end'} disabled />
                                </Col>
                            </Row>
                        </Col>
                        <Col span={24}>
                            <Row gutter={[12, 12]}>
                                <Col sm={6} span={0}></Col>

                                <Col sm={6} span={6} style={{ display: 'flex', width: '100%', alignItems: 'center', }}>
                                    <Row gutter={[12, 12]}>
                                        <Col span={12}>
                                        </Col>

                                        <Col span={12}>
                                            <Checkbox name={'checked'} onChange={balanceCheck} />
                                        </Col>
                                    </Row>
                                </Col>

                                <Col sm={12} span={18}>
                                    <CustomInputNumber precision={2} name={'received'} label={'Received'} placed={'end'} onChange={(val) => HandleOnchange(val)} />
                                </Col>
                            </Row>
                        </Col>
                        <Col span={24}>
                            <Row gutter={[12, 12]}>
                                <Col sm={12} span={0}></Col>

                                <Col sm={12} span={24}>
                                    <CustomInputNumber precision={2} name={'balance'} label={'Balance'} placed={'end'} />
                                </Col>
                            </Row>
                        </Col>
                    </Row>
                    {/* <div style={{background: 'red'}}>lsfjhgsdoik</div> */}
                </Col >
            </Row >
            <Flex flexEnd gap={'10px'}>


            </Flex>
        </Fragment>
    )
}

