import React from 'react'
import { SalesEntryPage } from './Partials/SalesEntryPage'

const SalesReturn = ({setSaleorder,getSaleorders,selectedDate}) => {
  return (
    <div>
      <SalesEntryPage setSaleorder={setSaleorder}  getSaleorders={getSaleorders} selectedDate={selectedDate}/>
    </div>
  )
}

export default SalesReturn
