import styled from "styled-components";


export const OverHid = styled.div`
/* overflow: auto hidden; */
height: 320px;
overflow-y: auto;
`;

export const CardDesign = styled.div`
/* background-color: ${props=>props.bgColor || 'black'}; */
color: #8056F7;
padding: 10px;
text-align: center;
border-radius: 10px;
border: 1px solid #8056F7;
background-color: var(--light-color);
/* &:nth-child(1) {
    background-color: var(--light-color);
} */
& h5 {
    font-size: 17px;
    font-weight: 500;
}
& h4 {
    font-size: 20px;
    font-weight: 600;
    padding: 10px 0;
}
&:hover {
    border: 1px solid var(--light-color);
background-color: #8056F7;
color:  var(--light-color);
}
/* &.red{
    background:var( --unpaid-color);
}
&.green{
    background:var( --paid-color);
}
&.yellow{
    background:var( --total-color);
} */
`;