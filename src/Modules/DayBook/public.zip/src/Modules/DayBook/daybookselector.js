const getDaybook = state => state.AddingDaybook.daybook

const selectors = {
    getDaybook, 
}

export default selectors