export const SET_DAYBOOK = 'SET_DAYBOOK'

export const setDaybook = daybook => {
    return{
        type:'SET_DAYBOOK',
        payload : daybook ,
    }
}
