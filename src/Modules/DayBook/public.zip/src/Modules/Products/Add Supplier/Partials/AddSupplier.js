import { UploadOutlined } from '@ant-design/icons'
import { Col, Form, Upload as Uploded } from 'antd'
import React, { useState } from 'react'
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { Row } from '../../../../Components/Row';
import Input from '../../../../Components/Form/Input';
import { TextAreas } from '../../../../Components/Form/TextArea';
import { InputNumber } from '../../../../Components/Form/InputNumber';
import Switch from '../../../../Components/Form/Switch';
import { useSelector } from 'react-redux';
import { CustomSwitch } from '../../../../Components/Form/CustomSwitch';
import { TopTitle } from '../../../../Components/Form/TopTitle';


const AddingSupplier = ({setCustomers}) => {
    const [form] = Form.useForm();
    const[switched,setSwitched] = useState(null);
    const onFinish = (values) => {
        setCustomers(values)
        console.log('Success:', values);
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    const member = useSelector(state=>state);
    console.log(member)
    
    const onhandleSwitch = () => {
        setSwitched(!switched);
      }
     
    const onReset =()=>{
        form.resetFields();

    }
    return (
        <div style={{ backgroundColor: 'white', padding: '20px 20px' }}>
            <Form
            form = {form}
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
              >
               
                  
               <TopTitle Heading={'ADD SUPPLIERS  :'}/>
               

                <Row gutter={[24, 24]} style={{ rowGap: '10px' }} >
                    <Col span={24} md={12}>

                        <Input label={'Supplier Name'} placeholder={'Supplier Name'} name={'supplier_name'}     rules={[
                                {
                                    required: true,
                                    message: 'Please Enter Supplier Name!',
                                }
                            ]} />
                    </Col>
                    <Col span={24} md={12}>

                <Input label={'Supplier Company'} placeholder={'Supplier Company'} name={'supplier_company'}     rules={[
                    {
                    required: true,
                    message: 'Please Enter Supplier Company!',
                    }
                 ]} />
                </Col>
                    <Col span={24} md={12}>
                        <Input label={'Mobile number'} placeholder={'Contact Number'} name={'mobile_number'} 
                            onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }} 
                            rules={[
                                {
                                    required: true,
                                    message: 'Please Enter Your Phone Number!',
                                }
                            ]}
                            
                            />
                             </Col>

                    <Col span={24} md={12}>
                        <Input label={'Email id'} name={'emailid'} placeholder={"Email ID"}    
 />
                    </Col>
                    <Col span={24} md={12}>
                    <Input label={'State'} placeholder={'State'} name={'state'}   />

                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'GSTIN'} placeholder={'GSTIN'} name={'gst'}    />
                    </Col>
                    <Col span={24} md={12}>
                    <TextAreas label={'Address'} placeholder={'Address'} name={'address'}
             />

                    </Col>

   
                <Col span={24} md={12}>
                        <Switch label={'Bank Details :' } onClick={()=>onhandleSwitch()}/>
                        { switched ? <div><InputNumber label={'Account Name '} name={'account_name'} placeholder={'Account Name'} /> 
                        <InputNumber label={'Account Number'} name={'account_number'} placeholder={'Account Number'} />
                        <InputNumber label={'Bank Name'} name={'bank_name'} placeholder={'Bank Name'} /></div>
                        : null}
                    
                    </Col> 
              
                </Row>
                <Flex center gap={'20px'} style={{ margin: '20px 0px' }}>
                    <Button.Primary text={'ADD'} htmlType={'submit'} />
                    <Button.Danger text={'RESET'} htmlType={'cancel'} onClick={()=>onReset()}/>
                </Flex>
            </Form>

        </div>
    )
}

export default AddingSupplier