import { UploadOutlined } from '@ant-design/icons'
import { Col, Form, Upload as Uploded } from 'antd'
import React, { useState } from 'react'
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { Row } from '../../../../Components/Row';
import Input from '../../../../Components/Form/Input';
import { TextAreas } from '../../../../Components/Form/TextArea';
import { InputNumber } from '../../../../Components/Form/InputNumber';
import Switch from '../../../../Components/Form/Switch';
import { useSelector } from 'react-redux';
import { CustomSwitch } from '../../../../Components/Form/CustomSwitch';
import { Select } from '../../../../Components/Form/Select';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import request from '../../../../utils/request';
import { CustomInputNumber } from '../../../../Components/Form/CustomInputNumber';


export const AddItems = ({ setProduct }) => {
    const [form] = Form.useForm();

    const URL = 'product/items_entry_view'
    
    const onFinish = (values) => {
        Addproduct(values)
        console.log('Success:', values);
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    const member = useSelector(state => state);
    console.log(member)

    const Addproduct = (values) => {
        request.post(`${URL}`, values)
            .then(function (response) {
                console.log(response);
                setProduct(values)
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    const option = [
        { label: 'Kg', value: 'kg' },
        { label: 'Litre', value: 'litre' },
        { label: 'Nos', value: 'nos' },
        { label: 'Metre', value: 'metre' },
    ]


    const onReset = () => {
        form.resetFields();

    }
    return (
        <Form
            form={form}
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off">

            <Row gutter={[12, 12]}>
                <Col span={24} md={12}>

                    <Input label={'Item/Product Name'} placeholder={'Product Name'} name={'item_name'} rules={[
                        {
                            required: true,
                            message: 'Please Enter Product Name!',
                        }
                    ]} />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'HSN Code'} placeholder={'HSN code'} name={'item_hsn'} rules={[
                        {
                            required: true,
                            message: 'Please Enter HSN Code!',
                        }
                    ]} />
                </Col>

                <Col span={24} md={12}>
                    <CustomInputNumber label={'Price'} precision={2} name={'sale_rate'} placeholder={"Price"} rules={[
                        {
                            required: true,
                            message: 'Please Enter Product Price!',
                        }
                    ]}
                    /></Col>
            </Row>
            <Flex center gap={'20px'} style={{ margin: '20px 0px' }}>
                <Button.Primary text={'ADD'} htmlType={'submit'} />
                <Button.Danger text={'RESET'} htmlType={'cancel'} onClick={() => onReset()} />
            </Flex>
        </Form>

    )
}