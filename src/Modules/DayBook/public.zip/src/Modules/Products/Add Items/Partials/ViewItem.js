import { UploadOutlined } from '@ant-design/icons'
import { Col, Form, Upload as Uploded } from 'antd'
import React, { useState } from 'react'
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { Row } from '../../../../Components/Row';
import Input from '../../../../Components/Form/Input';
import { TextAreas } from '../../../../Components/Form/TextArea';
import { InputNumber } from '../../../../Components/Form/InputNumber';
import Switch from '../../../../Components/Form/Switch';
import { useSelector } from 'react-redux';
import { CustomSwitch } from '../../../../Components/Form/CustomSwitch';
import { Select } from '../../../../Components/Form/Select';
import { TopTitle } from '../../../../Components/Form/TopTitle';


export const ViewItem = ({ setCustomers }) => {
    const [form] = Form.useForm();
    
    const member = useSelector(state => state);
    console.log(member)

    const option = [
        { label: 'Kg', value: 'kg' },
        { label: 'Litre', value: 'litre' },
        { label: 'Nos', value: 'nos' },
        { label: 'Metre', value: 'metre' },
    ]
    const onFinish = (values) => {
        setCustomers(values)
        console.log('Success:', values);
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const onReset = () => {
        form.resetFields();

    }
    return (
        <div style={{ backgroundColor: 'white', padding: '20px 20px' }}>
            <TopTitle Heading={'View Items'} />
            <Form
                form={form}
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off">

                <Row gutter={[24, 24]} style={{ rowGap: '10px' }} >
                    <Col span={24} md={12}>

                        <Input label={'Item/Product Name'} placeholder={'Product Name'} 
                        name={'product_name'} />
                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'HSN Code'} placeholder={'HSN code'} name={'hsn_code'}/>
                    </Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Item Quantity'} placeholder={'Item Quantity'} 
                        name={'item_quantity'}  /></Col>

                    <Col span={24} md={12}>
                        <Input options={option} label={'Item Unit Name'} name={'item_unit_name'} rules={[
                            {
                                required: true,
                                message: 'Please Enter Your Item Unit Name!',
                            }
                        ]} />
                    </Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'MRP'} name={'mrp'} placeholder={"MRP"} rules={[
                            {
                                required: true,
                                message: 'Please Enter MRP!',
                            }
                        ]}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Buy Rate'} name={'buy_rate'} placeholder={"Buy Rate"} rules={[
                            {
                                required: true,
                                message: 'Please Enter Buy rate!',
                            }
                        ]}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Price'} name={'price'} placeholder={"Price"} rules={[
                            {
                                required: true,
                                message: 'Please Enter Product Price!',
                            }
                        ]}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Discount Percentage(%)'} name={'discount_percentage'} placeholder={"Discount Percentage"} rules={[
                            {
                                required: true,
                                message: 'Please Enter Discount Percentage!',
                            }
                        ]}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Discount Amount'} name={'discount_amount'} placeholder={"Discount Amount"} disabled={'fixedamount'}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'GST Percentage(%)'} name={'gst_percentage'} placeholder={"GST percentage"} rules={[
                            {
                                required: true,
                                message: 'Please Enter GST Percentage!',
                            }
                        ]}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'GST Amount'} name={'gsr_amount'} placeholder={"GST Amount"} disabled={'fixedamount'}
                        /></Col>
                    <Col span={24} md={12}>
                        <InputNumber label={'Total Amount'} name={'total_amount'} placeholder={"Total Amount"} rules={[
                            {
                                required: true,
                                message: 'Please Enter Total Amount!',
                            }
                        ]}
                        /></Col>


                </Row>
            </Form>

        </div>
    )
}
