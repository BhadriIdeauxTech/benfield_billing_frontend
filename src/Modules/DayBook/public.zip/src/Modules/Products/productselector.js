const getProduct = state => state.AddingProduct.product

const selectors = {
    getProduct, 
}

export default selectors