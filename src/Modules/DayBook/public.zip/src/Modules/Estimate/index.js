import React from 'react'
import { EstimateEntryPage } from './Partials/EstimateEntryPage'

const Estimate = () => {
  return (
    <div>
        <EstimateEntryPage />
    </div>
  )
}

export default Estimate