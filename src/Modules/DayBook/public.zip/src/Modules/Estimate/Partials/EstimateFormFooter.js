import { Card, Col, Form } from 'antd'
import React, { Fragment } from 'react'
import dayjs from 'dayjs'
import OutSourceData from './Data'
import Flex from "../../../Components/Flex"
import { CustomInputNumber } from "../../../Components/Form/CustomInputNumber"
import { Row } from "../../../Components/Row"
import { CustomSelect } from '../../../Components/Form/CustomSelect'
import { TextAreas } from '../../../Components/Form/TextArea'
import Checkbox from '../../../Components/Form/Checkbox'
import { useState } from 'react'


export const EstimateFormFooter = ({ BalanceOnChange, setReceivedRow, TotalBalance, setRoundDecimalValue, RoundOffChecked, round, footerCalData, setSaleorder, tableSecondaryData }) => {

    const [switched, setSwitched] = useState(true);
    const onhandleSwitch = () => {
        setSwitched(!switched);
    }
    const CusData = [
        {
            label: 'Cash',
            value: 'Cash'
        },
        {
            label: 'Cheque',
            value: 'suplier_cheque_payment'
        },
        {
            label: 'UPI',
            value: 'UPI'
        }
    ]
    const [payType, setPayType] = useState('');

    const handleSelectChange = (values) => {
        setPayType(values);
    }
    const suppliers = [
        { label: 'Supplier 1', value: 'suplier_one' },
        { label: 'Supplier 2', value: 'suplier_two' },
        { label: 'Supplier 3', value: 'suplier_three' },
    ]
    const Cheque = [

        { label: 'Cash', value: 'suplier_credit_payment' },
        { label: 'Cheque', value: 'suplier_advance_payment' },
        { label: 'UPI', value: 'suplier_debit_amount' },
    ]

    const handleRoundChecked = (e) => {
        RoundOffChecked(e.target.checked)
    }

    return (
        <Fragment>
              <Row gutter={[24, 24]} >
                <Col lg={10} md={12} span={24}>
                    {/* <Row gutter={[12, 12]} style={{ backgroundColor: 'white', padding: '15px', borderRadius: '6px' }}>

                        <Col span={24} md={20} >
                            <Select options={Cheque} label={'Supplier Pay type '} placeholder={'Select Payement Type'} onChange={handleSelectChange} name={'supplier_pay_type'} rules={[
                                {
                                    required: true,
                                    message: 'Enter the Cheque !'
                                }
                            ]} /></Col>

                        
                        {payType === 'suplier_advance_payment' && (
                            <div>
                                <CustomInputNumber label={'Ref No.'} name={'refno'} rules={[
                                    {
                                        required: true,
                                        message: 'Enter the Ref no!'
                                    }
                                ]} />
                            </div>
                        )}
                       
                        <Col span={24} md={12}>
                            <Switch label={'Cash'} label2={'Credit'} defaultChecked onClick={() => onhandleSwitch()} />
                        </Col>
                        <br />
                        <Col span={24} md={24}></Col>
                        <Col span={24} md={20}>

                            {switched ?
                                <Row>
                                    <Flex>
                                        <Col span={24} md={20}>
                                            <CustomInputNumber label={'Credit period'} name={'credit_period'} placeholder={'Credit period'} />
                                        </Col>&nbsp;<b>Days</b>
                                    </Flex>
                                </Row> : null}
                        </Col>
                    </Row> */}
                </Col>

                <Col lg={4} md={0} span={0}></Col>

                <Col lg={10} md={12} span={24}>
                    <Card>
                        <Row gutter={[12, 12]}>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Quantity'}
                                    name={'total_qty'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Tax'}
                                    name={'total_tax'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                            <Col span={24} lg={12}>
                                <CustomInputNumber precision={2}
                                    label={'Total Amount'}
                                    name={'total_rowamount'}
                                    placed={'end'}
                                    disabled
                                />
                            </Col>
                        </Row>
                    </Card>
                </Col>

                <Col lg={10} md={4} span={0}>
                    {/* <Row gutter={[12, 12]} style={{ backgroundColor: 'white', padding: '15px', borderRadius: '6px' }}>
                        <Col span={24} lg={20}>
                            <CustomInputNumber precision={2}
                                label={'Old Balance'}
                                name={'old_balance'}
                                // placed={'end'}
                                disabled
                            />
                        </Col>
                        <Col span={24} lg={20}>
                            <CustomInputNumber precision={2}
                                label={'Advanced Amount'}
                                name={'advancedamt'}
                                // placed={'end'}
                                disabled
                            />
                        </Col>
                    </Row> */}
                </Col>

                <Col lg={14} md={24} span={24}>
                    <Row gutter={[12, 12]}>
                        <Col span={24}>
                            <Row gutter={[12, 12]}>
                            <Col sm={12} span={24}></Col>
                                {/* <Col sm={12} span={24} style={{
                                    display: 'flex',
                                    alignItems: 'end',
                                }}>
                                    <Row gutter={[12, 12]}>
                                        <Col lg={16} span={12}>
                                            <Checkbox label={'Round Off'} onChange={handleRoundChecked} />
                                        </Col>

                                        <Col lg={8} span={12}>
                                           
                                            {round ? (
                                                <CustomInputNumber precision={2} name={'round_off'} placed={'end'} />
                                            ) : (
                                                <CustomInputNumber precision={2} name={'round_off'} placed={'end'} disabled />
                                            )}
                                        </Col>
                                    </Row>
                                </Col> */}

                                <Col sm={12} span={24}>
                                    <CustomInputNumber precision={2} name={'total_amount'} label={'Total'} placed={'end'} disabled />
                                </Col>
                            </Row>
                        </Col>
                        <Col span={24}>
                            <Row gutter={[12, 12]}>
                                <Col sm={6} span={0}></Col>

                                {/* <Col sm={6} span={6} style={{ display: 'flex', width: '100%', alignItems: 'center', }}>
                                    <Row gutter={[12, 12]}>
                                        <Col span={12}>
                                        </Col>

                                        <Col span={12}>
                                            <Checkbox />
                                        </Col>
                                    </Row>
                                </Col> */}

                                {/* <Col sm={12} span={18}>
                                    <CustomInputNumber precision={2} name={'received'} label={'Received'} placed={'end'} />
                                </Col> */}
                            </Row>
                        </Col>
                        <Col span={24}>
                            {/* <Row gutter={[12, 12]}>
                                <Col sm={12} span={0}></Col>

                                <Col sm={12} span={24}>
                                    <CustomInputNumber precision={2} name={'balance'} label={'Balance'} placed={'end'} disabled />
                                </Col>
                            </Row> */}
                        </Col>
                    </Row>
                    {/* <div style={{background: 'red'}}>lsfjhgsdoik</div> */}
                </Col >
            </Row >
            <Flex flexEnd gap={'10px'}>


            </Flex>
        </Fragment>
    )
}

