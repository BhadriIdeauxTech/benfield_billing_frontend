import React from 'react'
import LoginPage from './Partials/LoginPage'

const LoginPagemain = () => {
  return (
    <div>
      <LoginPage/>
    </div>
  )
}

export default LoginPagemain
