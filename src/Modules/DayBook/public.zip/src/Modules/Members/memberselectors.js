const getMembers = state => state.AddingMembers.members

const selectors = {
    getMembers, 
}

export default selectors