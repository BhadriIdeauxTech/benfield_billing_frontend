export const SET_MEMBERS = 'SET_MEMBERS'

export const setMembers = members => {
    return{
        type:'SET_MEMBERS',
        payload : members ,
    }
}
