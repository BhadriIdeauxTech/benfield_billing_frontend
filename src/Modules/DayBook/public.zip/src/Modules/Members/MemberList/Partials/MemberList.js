import React, { useEffect, useState } from 'react'
import Flex from '../../../../Components/Flex';
import Button from '../../../../Components/Form/Button'
import { Table } from '../../../../Components/Table'
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import { Modal as Modals } from '../../../../Components/Modal';
import { MdNotificationsActive, MdOutlineNotificationsActive } from 'react-icons/md';
import { Col, Modal } from 'antd';
import { Row } from '../../../../Components/Row';
import { SearchInput } from '../../../../Layout/style';
import { SearchBar } from '../../../../Components/Form/SearchBar';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import ViewMember from './ViewMember';
import request from '../../../../utils/request';
import dayjs from 'dayjs';
import { useParams } from 'react-router-dom';




const ViewMemberList = ({ getMembers, isEnabled }) => {

  const URL = 'api/g_users'

  const { id } = useParams();

  const [status, setStatus] = useState('off');

  const URLE = 'api/g_user_Enable'

  const URLD = 'api/g_user_disable'

  const [dataSource, setDataSource] = useState(getMembers);

  const [isModalOpen, setIsModalOpen] = useState(false);

  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState(null)

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const handleChage = (record) => {
    console.log(record, 'hhhhhhhhhhhhhhhhhhhh')
    // setStatus(!status);
    Getpatch(record);

  };

  useEffect(() => {
    GetMamber();
    // Getpatch();
  }, [])

  // useEffect(() => {
  // form.setFieldsValue({ business_name: selectedSupplier.business_name })
  // form.setFieldsValue({ email: selectedSupplier.email })
  // form.setFieldsValue({ phone_no: selectedSupplier.phone_no })
  // form.setFieldsValue({ phone_no2: selectedSupplier.phone_no2 })
  // form.setFieldsValue({ gstin: selectedSupplier.gstin })
  // form.setFieldsValue({ address: selectedSupplier.address })

  // }, [selectedSupplier])

  const GetMamber = (values) => {
    request.get(`${URL}`, values)
      .then(function (response) {
        console.log(response.data, 'business');
        setDataSource(response.data)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  const Getpatch = (values) => {

    if (values.status === 'Disabled') {
      console.log('Disabled')
      request.patch(`${URLE}/${values.id}`)
        .then(function (response) {
          console.log('User updated successfully:', response.data);
          setDataSource(response.data)
          GetMamber();

        })
        .catch(function (error) {
          console.error('Error updating user:', error);
        });
    }
    else {
      console.log('Enabbbbbbbbbbbbbbb')
      request.patch(`${URLD}/${values.id}`)
        .then(function (response) {
          console.log('User updated successfully:', response.data);
          setDataSource(response.data)
          GetMamber();

        })
        .catch(function (error) {
          console.error('Error updating user:', error);
        });
    }
    // request.patch(`${URLS}`, { [field]: value })
    //     .then(function (response) {
    //       console.log('User updated successfully:', response.data);
    //         setDataSource(response.data)
    //     })
    //     .catch(function (error) {
    //       console.error('Error updating user:', error);
    //     });
  }
  console.log(setDataSource, 'yyyyyyyyyyyyyyyyyyy')


  // useEffect(() => {
  //   setDataSource(getMembers)
  // }, [getMembers])

  console.log(getMembers)
  console.log(dataSource, 'dataSource')

  const buttonStyle = {
    backgroundColor: status === 'enabled' ? 'red' : 'green',
    color: 'white',
    padding: '8px 16px',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  };

  //   const onViewmarket = (record) => {
  //     setModalContent(<ViewMP record={record}/>);
  //     setModalTitle("Added Marketing Person");
  //     showModal();

  //   }

  //   const onEditmarket = (record) => {
  //     setModalContent(<EditMP setDetails={record} handleOk={handleOk}/>);
  //     setModalTitle("Update Details here");
  //     showModal();
  //   }

  const onViewmember = (record) => {
    setModalContent(<ViewMember record={record} />);
    setModalTitle("Member Details");
    showModal();
  }


  const columns = [
    {
      title: 'S.No',
      render: (value, item, index) => index + 1,
    },
    {
      title: 'Date',
      dataIndex: 'created_at',
      render: (date) => {
        return dayjs(date).format('DD\\MM\\YYYY');
      },
    },
    {
      title: 'Name',
      dataIndex: 'name'
    },
    {
      title: 'Email ID',
      dataIndex: 'email'
    },
    {
      title: 'Role',
      dataIndex: 'user_role'
    },
    {
      title: 'Status',
      dataIndex: 'status',
      render(status, record) {
        return {
          props: {
            style: {
              color:
                record.status === "Disabled"
                  ? "red"
                  : record.status === "Enabled"
                    ? "green"
                    : "white",
            },
          },
          children: <div>{status}</div>,
        };


      }
    },
    {
      title: 'Action',
      render: (record) => {
        return (
          <>
            <Flex spaceEvenly>
              <Button.Primary
                text={<EditOutlined />}
                onClick={() => handleChage(record)}
              />


              {/* style={buttonStyle} disabled={!isEnabled} */}

              {/* <Button.Success text={<EyeOutlined />}  onClick={() => {
                onViewmember(record);
              }}
              /> */}
              {/* <Button.Danger text={<MdNotificationsActive />}  onClick={() => {
                activrBtns(record);
              }}
              /> */}

            </Flex>
          </>
        )
      }
    },
  ]


  return (
    <div>

      <TopTitle Heading={'Member List'} />

      <Table columns={columns} data={dataSource} />
      <Modals isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} modalTitle={modalTitle} modalContent={modalContent} width={1200} />
    </div>
  )
}

export default ViewMemberList