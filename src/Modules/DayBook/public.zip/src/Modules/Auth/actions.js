/* eslint-disable no-unused-vars */
import request from '../../utils/request'
import initializeApp from '../../utils/initializeApp'

export const SIGN_IN_SUCCESS = 'SIGN_IN_SUCCESS'
export const LOGOUT_SUCCESS = 'LOGOUT_SUCCESS'

export const SignInSuccess = token => {
  return {
    type: SIGN_IN_SUCCESS,
    token,
  }
}

export const LogOutSuccess = () => {
  console.log('called')
  return {
    type: LOGOUT_SUCCESS,
  }
}

export const SignIn = data => async dispatch => {
  try {
    const authData = await request.post(`api/login`, {
      ...data,
    })

    // Mock API, add the origin API and payload data
    initializeApp (authData?.data) // pass the token to this function
    dispatch(SignInSuccess(authData?.data))
  } catch (error) {
    console.error('Getting error while login', error)
  }
}
