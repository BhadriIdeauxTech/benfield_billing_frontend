import React, { useEffect, useState } from 'react'

import Button from '../../../../Components/Form/Button';

import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';

import { Modal as Modals } from '../../../../Components/Modal';
import { MdOutlineNotificationsActive } from 'react-icons/md';



import Flex from '../../../../Components/Flex';
import { Table } from '../../../../Components/Table';
import CustomerView from './CustomerView';
import { SearchInput } from '../../../../Layout/style';
import { Row } from '../../../../Components/Row';
import { Col } from 'antd';
import { SearchBar } from '../../../../Components/Form/SearchBar';
import CustomerPay from './CustomerPay';
import { AiFillAccountBook } from "react-icons/ai";
import { TopTitle } from '../../../../Components/Form/TopTitle';


const ViewCustomerList = ({getCustomers}) => {
  const [dataSource, setDataSource] = useState(getCustomers);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [modalTitle, setModalTitle] = useState('');
  const [modalContent, setModalContent] = useState(null)

  const showModal = () => {
    setIsModalOpen(true);
  };
  const handleOk = () => {
    setIsModalOpen(false);
  };
  const handleCancel = () => {
    setIsModalOpen(false);
  };
//   useEffect(() => {
//     setDataSource(getMarketingperson)
//   }, [getMarketingperson])

//   console.log(getMarketingperson)
  console.log(dataSource, 'dataSource')

  const onViewcustomer = (record) => {
    setModalContent(<CustomerView record={record}/>);
    setModalTitle("Customer Details");
    showModal();

  }
  const onViewcustomerpay = (record) => {
    setModalContent(<CustomerPay record={record}/>);
    setModalTitle("Customer Pay");
    showModal();

  }
  

//   const onEditmarket = (record) => {
//     setModalContent(<EditMP setDetails={record} handleOk={handleOk}/>);
//     setModalTitle("Update Details here");
//     showModal();
//   }
  const columns = [
    {
      title: 'S.No',
      render: (value, item, index) => index + 1,
    },
    {
      title: 'Date',
      dataIndex: 'date'
    }, 
    {
      title: 'Customer Name',
      dataIndex: 'customer_name'
    }, 
    {
      title: 'Mobile number',
      dataIndex: 'mobile_number'
    }, 
    {
      title: 'Company Name',
      dataIndex: 'company_name'
    },
    {
      title: 'Advance Amount',
      dataIndex: 'advance_amount'
    }, 
    {
      title: 'Amount Paid',
      dataIndex: 'amount_paid'
    },{
      title: 'Balance Amount',
      dataIndex: 'balance_amount'
    }, 
  
  {
      title: 'Action',
      render: (record) => {
        console.log(record,"record")
        return (
          <>
            <Flex spaceEvenly>
              <Button.Success
                text={<EditOutlined/> }/>

              <Button.Success text={<EyeOutlined />}onClick={() => {onViewcustomer(record)}}
              
              />
                <Button.Primary text={<AiFillAccountBook />}onClick={() => {onViewcustomerpay(record)}}
              
              />
            </Flex>
          </>
        )
      }
    },
  ]
  // const [dataSource, setDataSource] = useState([
  //   {
  //     id: 1,
  //     Member_Id: 'IU776',
  //     name: 'Mike',
  //     profile:'PIC',
  //     contact: '98754155',
  //     location: 'Ngl',
  //     role:'Collection'
  //       },
  //   {
  //     id: 2,
  //     Member_Id: 'IU777',
  //     name: 'Tom',
  //     profile:'PIC',
  //     contact: '987541554',
  //     location: 'klm',
  //     role:'Collection'
  //      },
  //   {
  //     id: 3,
  //     Member_Id: 'IU778',
  //     name: 'Jerry',
  //     profile:'PIC',
  //     contact: '987541557',
  //     location: 'Scd',
  //     role:'Sales'
  //      },
  //   {
  //     id: 4,
  //     Member_Id: 'IU779',
  //     name: 'Kaushik',
  //     profile:'PIC',
  //     contact: '9875415547',
  //     location: 'Mtm',
  //     role:'Collection'
  //      },
  //   {
  //     id: 5,
  //     Member_Id: 'IU780',
  //     name: 'Anoj',
  //     profile:'PIC',
  //     contact: '9875415512',
  //     location: 'kzt',
  //     role:'Sales'
  //      },
  //   {
  //     id: 6,
  //     Member_Id: 'IU781',
  //     name: 'Jebarson',
  //     profile:'PIC',
  //     contact: '9875415574',
  //     location: 'mmt',
  //     role:'Sales'
  //      },
  //   {
  //     id: 7,
  //     Member_Id: 'IU782',
  //     name: 'Jibin',
  //     profile:'PIC',
  //     contact: '9875415547',
  //     location: 'klmcd',
  //     role:'Collection'
  //      },
  //   {
  //     id: 8,
  //     Member_Id: 'IU783',
  //     name: 'Singh',
  //     profile:'PIC',
  //     contact: '9875415514',
  //     location: 'Ftr',
  //     role:'Collection'
  //      },
  //   {
  //     id: 9,
  //     Member_Id: 'IU784',
  //     name: 'Walter',
  //     profile:'PIC',
  //     contact: '9875415515',
  //     location: 'Wiy',
  //     role:'Sales'
  //      },
  // ])

  return (
    <div>
 
    
    <TopTitle Heading={'CUSTOMER LIST  :'}/>
    <Row gutter={[24,24]} >
      <Col><SearchBar name='search_customer' placeholder='Search customers'/></Col>
    
    </Row>
      <Table columns={columns} data={dataSource} />
      <Modals isVisible={isModalOpen} handleOk={handleOk}  handleCancel={handleCancel} modalTitle={modalTitle} modalContent={modalContent} width={1200} />
    </div>
  )
}

export default ViewCustomerList