import styled from "styled-components";

export const StyledCustomer = styled.div`

/* display: flex;
justify-content: space-between; */
background:var(--light-color);
height:50px;
padding-left:20px;
display:flex;
align-items:center;
margin-bottom:20px;



/* // &one {
//     width: 100px;
//   height: 100px;


// } */

`