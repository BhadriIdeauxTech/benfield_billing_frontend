import { Col, Form } from 'antd';
import React from 'react'
import { TextAreas } from '../../../../Components/Form/TextArea';
import Switch from '../../../../Components/Form/Switch';
import { CustomInputNumber } from '../../../../Components/Form/CustomInputNumber';
import Input from '../../../../Components/Form/Input';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { useState } from 'react';
import { useSelector } from 'react-redux';
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { Row } from '../../../../Components/Row';
import Label from '../../../../Components/Form/Label';
import request from '../../../../utils/request';

const AddingCustomers = ({ getCustomer, handleCancel }) => {
    const [form] = Form.useForm();
    const [switched, setSwitched] = useState(null);

    const URL = 'customers/add_customer/'

    const onFinish = (values) => {
        // setCustomers(values)
        Addcustomer(values)
        console.log('Success:', values);
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };
    const member = useSelector(state => state);
    console.log(member)

    const onhandleSwitch = () => {
        setSwitched(!switched);
    }

    const Addcustomer = (values) => {
        request.post(`${URL}`, values)
            .then(function (response) {
                console.log(response);
                getCustomer(values)
                form.resetFields();

                if (handleCancel) {
                    form.resetFields();
                    handleCancel();
                }
            })
            .catch(function (error) {
                console.log(error);
            });
    }

    const onReset = () => {
        form.resetFields();
    }
    return (
        <Form
            form={form}
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off">
            <Row gutter={[24, 24]}>
                <Col span={24} md={12} >
                    <Input label={'Customer Name'} placeholder={'Customer Name'} name={'customer_name'} rules={[
                        {
                            required: true,
                            message: 'Please Enter Customer Name!',
                        }
                    ]} />
                </Col>
                <Col span={24} md={12}>
                <Input label={'Mobile number'} placeholder={'Contact Number'} name={'mobile_number'}
                        maxLength={10}
                        onKeyPress={(event) => {
                            if (!/[0-9]/.test(event.key)) {
                                event.preventDefault();
                            }
                        }}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Your Phone Number!',
                            },

                            {
                                min: 10,
                                message: 'Phone Number must be at least 10 characters!'
                            }
                        ]} />
                    {/* <CustomInputNumber label={'Mobile number'} placeholder={'Contact Number'} name={'mobile_number'}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Your Phone Number!',
                            }
                        ]} /> */}
                </Col>
                <Col span={24} md={12}>
                    <Input label={'Company Name'} placeholder={'Company Name'} name={'customer_company_name'}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Details!',
                            }
                        ]} />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'Email id'} name={'email'} type="email" placeholder={"Email ID"}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Details!',
                            }
                        ]} />
                </Col>
                <Col span={24} md={12}>
                    <Input label={'GSTIN'} placeholder={'GSTIN'} name={'gstin'} style={{textTransform:'uppercase'}}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Details!',
                            }
                        ]} />
                </Col>
                <Col span={24} md={12}>
                    <CustomInputNumber label={'Advance Amount'} precision={2} placeholder={'Advance amount'}
                        name={'advanced_amt'}
                    />
                </Col>

                <Col span={24} md={12}>
                    <TextAreas label={'Address'} placeholder={'Address'} name={'customer_address'}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Details!',
                            }
                        ]} />
                </Col>
                <Col span={24} md={12}>
                    <Label>Credit Limit</Label>
                    <Col md={7}>
                        <Switch onClick={() => onhandleSwitch()} checked={switched} name={'credit_limit'} />
                    </Col>
                    {switched ? <CustomInputNumber label={'Credit amount'} precision={2} name={'credit_amt'} placeholder={'Credit amount'}
                        rules={[
                            {
                                required: true,
                                message: 'Please Enter Details!',
                            }
                        ]} /> : null}
                </Col>
                <Flex center gap={'20px'} style={{ margin: '20px 0px' }}>
                    <Button.Primary text={'Add'} htmlType={'submit'} />
                    <Button.Danger text={'Reset'} htmlType={'cancel'} onClick={() => onReset()} />
                </Flex>
            </Row><br />
        </Form>
    )
}

export default AddingCustomers