import React from 'react'
import { useState } from 'react';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { Col, Form } from 'antd';
import { Row } from '../../../../Components/Row';
import { Select } from '../../../../Components/Form/Select';
import { CustomInputNumber } from '../../../../Components/Form/CustomInputNumber';
import { CustomDatePicker } from '../../../../Components/Form/CustomDatePicker';
import Flex from '../../../../Components/Flex';
import Button from '../../../../Components/Form/Button';
import dayjs from 'dayjs';
import { phoneValidator } from '../../../../utils/PhnNumberValidator';
import Input from '../../../../Components/Form/Input';
import { useEffect } from 'react';
import request from '../../../../utils/request';
import { DatePicker } from 'antd';
import Label from '../../../../Components/Form/Label';
import { toast } from 'react-toastify';

const CustomerPay = ({ setCustomer, getCustomer }) => {
    const [form] = Form.useForm();
    const [SelectedDate, setSelectedDate] = useState(dayjs().format('MMMM DD, YYYY'));
    const handleOnChange = (date) => {
        setSelectedDate(date);
    };

    const URL = 'customers/add_customer/';
    const URLS1 = 'customers/customer_advance_amt_payment/'
    const URLS2 = 'customers/customer_credit_amt_payment/'
    const URLS3 = 'customers/customer_debit_amt_payment/'

    const URL1 = URLS1
    const URL2 = URLS2
    const URL3 = URLS3

    const [selectedCustomer, setSelectedCustomer] = useState({})

    const [payType, setPayType] = useState('');

    const handleSelectChange = (values) => {
        setPayType(values);
    }
    const [cashType, setCashType] = useState('');

    const handleSelectChanges = (values) => {
        setCashType(values);
    }
    const onFinish = (values) => {
        console.log('Success:', values);


        let result = {
            customer: values.customer,
            customer_name: values.customer_name,
            previous_advanced_amt: values.advanced_amt,
            mobile_number: values.mobile_number,
            payment_type: values.payment_type,
            payment_date: values.payment_date,
            advanced_amt: values.advanced_amt_pay,
            previous_credit_amt: values.credit_amt_balance,
            cheque_no: values.refno,
            credit_amt: values.credit_amt_pay,
            debit_amt: values.debt_amt_pay,
            previous_debit_amt: values.debit_amt,
        };
        PostCustomer(result)
    };
    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const onReset = () => {
        form.resetFields();
    };

    const PostCustomer = (values) => {
        if (payType === 'customer_advance_payment') {
            request.post(`${URL1}`, values)
                .then(function (response) {
                    console.log(response.data, 'supplier');
                    // setCustomer(response.data)
                    toast.success("Success")
                    form.resetFields();
                })
                .catch(function (error) {
                    console.log(error);
                    toast.error("Faild")
                });
        }
        else if (payType === 'customer_credit_payment') {
            request.post(`${URL2}`, values)
                .then(function (response) {
                    console.log(response);
                    toast.success("Success")
                    form.resetFields();
                })
                .catch(function (error) {
                    console.log(error);
                    toast.error("Faild")
                });
        }
        else if (payType === 'customer_debit_amount') {
            request.post(`${URL3}`, values)
                .then(function (response) {
                    console.log(response);
                    toast.success("Success")
                    form.resetFields();
                })
                .catch(function (error) {
                    console.log(error);
                    toast.error("Faild")
                });
        }
    };


    useEffect(() => {
        GetCustomer();
    }, [])

    useEffect(() => {
        form.setFieldsValue({ customer_name: selectedCustomer.customer_name })
        form.setFieldsValue({ credit_amt: selectedCustomer.credit_amt })
        form.setFieldsValue({ advanced_amt: selectedCustomer.advanced_amt })
        form.setFieldsValue({ debit_amt: selectedCustomer.debit_amt })
        form.setFieldsValue({ credit_amt_balance: selectedCustomer.credit_amt_balance })
        form.setFieldsValue({ mobile_number: selectedCustomer.mobile_number })
        form.setFieldsValue({ customer: selectedCustomer.id })


    }, [selectedCustomer])


    const GetCustomer = (values) => {
        request.get(`${URL}`, values)
            .then(function (response) {
                console.log(response.data, 'supplier');
                setCustomer(response.data)
            })
            .catch(function (error) {
                console.log(error);
            });
    }



    // ===========  Customer MobileNumber Data =========

    const CustomerMobiles = getCustomer?.map(mob => ({ label: mob.mobile_number, value: mob.id }))

    const handleSelectedCustomer = (value) => {
        const SelectedCustomerDetails = getCustomer?.find((mem) => mem.id === value)
        setSelectedCustomer(SelectedCustomerDetails);
    }

    console.log(CustomerMobiles, 'dddd')

    const paytype = [
        { label: 'Advanced Payment', value: 'customer_advance_payment' },
        { label: 'Credit Payment', value: 'customer_credit_payment' },
        { label: 'Debit Amount', value: 'customer_debit_amount' },
    ]
    const ChequesBank = [

        { label: 'Cash', value: 'Cash' },
        { label: 'Cheque', value: 'Cheque' },
        { label: 'UPI', value: 'UPI' },
    ]
    return (

        <Form
            form={form}
            labelCol={{
                span: 24,
            }}
            wrapperCol={{
                span: 24,
            }}
            initialValues={
                {
                    payment_date: dayjs(),
                    payment_type: 'Cash'
                }
            }
            onFinish={onFinish}
            onFinishFailed={onFinishFailed}
            autoComplete="off">
            <Row gutter={[24, 24]}>
                <Col span={24} md={10} >
                    <Select options={paytype} label={'Payment Type'} placeholder={'Payment Type'}
                        onChange={handleSelectChange}
                        name={'supplier_pay_type'}
                        rules={[
                            {
                                required: true,
                                message: 'Enter the Paytype !'
                            }
                        ]} /></Col>

                <Col span={24} md={14} >
                    <Select options={CustomerMobiles} showSearch label={'Mobile Number'}
                        placeholder={'Select Number'} name={'mobile_number_id'}
                        onChange={handleSelectedCustomer}
                    />
                    <Input name={'mobile_number'} display={'none'} />

                    <Input disabled label={'Customer Name '} placeholder={'Customer name'} name={'customer_name'}
                        rules={[
                            {
                                required: true,
                                message: 'Enter the Customer Name !'
                            }
                        ]} />
                    <Select options={ChequesBank} label={'Customer Pay type '}
                        placeholder={'Select Payement Type'} onChange={handleSelectChanges}
                        name={'payment_type'}
                        rules={[
                            {
                                required: true,
                                message: 'Enter the details !'
                            }
                        ]} />
                    {cashType === 'Cheque' && (
                        <div>
                            <CustomInputNumber label={'Ref No.'} name={'cheque_no'} placeholder={'Reference No'} rules={[
                                {
                                    required: true,
                                    message: 'Enter the Ref no!'
                                }
                            ]} />
                        </div>
                    )}
                    <CustomDatePicker label={'Payment Date'} onChange={handleOnChange} name={'payment_date'}
                        rules={[
                            {
                                required: true,
                                message: 'Enter the Payment Date !'
                            }
                        ]} />
                    <br />

                    {/* Supplier Advanced Payment */}
                    {payType === 'customer_advance_payment' && (
                        <div>
                            <CustomInputNumber precision={2} label={'Previous Advanced Amount'} name={'advanced_amt'} disabled />
                            <CustomInputNumber precision={2} label={'Advanced Amount (paid)'} name={'advanced_amt_pay'}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Enter the Advanced Amount !'
                                    }
                                ]} />
                        </div>
                    )}
                    {/* Supplier Credit Payment */}
                    {payType === 'customer_credit_payment' && (<div>
                        <CustomInputNumber precision={2} label={'Previous Credit Amount'} name={'credit_amt_balance'} disabled />
                        <CustomInputNumber precision={2} label={'Payment'} name={'credit_amt_pay'} rules={[
                            {
                                required: true,
                                message: 'Enter the Amount !'
                            }
                        ]} />

                    </div>
                    )}


                    {/* Supplier Debit Payment */}
                    {payType === 'customer_debit_amount' && (

                        <div>
                            <CustomInputNumber precision={2} label={'Previous Debit Amount'} name={'debit_amt'} disabled />
                            <CustomInputNumber precision={2} label={'Debit Amount'} name={'debt_amt_pay'}
                                rules={[
                                    {
                                        required: true,
                                        message: 'Enter the Advanced Amount !'
                                    }
                                ]} />
                        </div>
                    )}
                </Col>
                <Input name={'customer'} style={{ display: 'none' }} />

                <Flex center gap={'20px'}>
                    <Button.Primary text={'Save'} htmlType={'submit'} />
                    <Button.Danger text={'Reset'} htmlType={'cancel'} onClick={() => onReset()} />
                </Flex>
            </Row>

        </Form>

    )
}

export default CustomerPay