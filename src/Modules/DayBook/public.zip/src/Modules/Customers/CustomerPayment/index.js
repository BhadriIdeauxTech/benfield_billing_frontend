import React from 'react'
import CustomerPay from './Partials/CustomerPay'
import { TopTitle } from '../../../Components/Form/TopTitle'
import { CustomCard } from '../../../Components/CustomCard'

const CustomerPaymentDetails = ({ setCustomer, getCustomer }) => {
  return (
    <div>
      <TopTitle Heading={'Customer Payments'} />

      <CustomCard width={'95%'}>
        <CustomerPay setCustomer={setCustomer} getCustomer={getCustomer} />
      </CustomCard>
    </div>
  )
}

export default CustomerPaymentDetails