const getCustomer = state => state.AddingCustomers.customer

const selectors = {
    getCustomer, 
}

export default selectors