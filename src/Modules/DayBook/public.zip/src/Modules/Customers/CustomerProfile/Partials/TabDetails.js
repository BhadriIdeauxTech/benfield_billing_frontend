import React from 'react'
import Creditpay from './Creditpay';
import AdvancedPay from './AdvancedPay';
import Debitpay from './Debitpay';
import Sales from './Sales';
import { Tabs } from '../../../../Components/Tabs';
import SalesRetun from './SalesRetun';
import Quatation from './Quatation';
import { useEffect } from 'react';
import { useState } from 'react';

const TabDetails = ({customerProfile}) => {

    const [CustomerDetails, setCustomerDetails] = useState([])

useEffect(() => {
    setCustomerDetails(customerProfile)
}, [customerProfile])

    console.log(customerProfile,'ffffffffffffffffffffffffff')
    const items = [
        {
            key: '1',
            label: `Sales`,
            children: <Sales CustomerDetails={CustomerDetails} />,
            
        },
        {
            key: '2',
            label: `Sales Return`,
            children: <SalesRetun CustomerDetails={CustomerDetails} />,
        },
        {
            key: '3',
            label: `Quotation`,
            children: <Quatation CustomerDetails={CustomerDetails} />,
        },
        {
            key: '4',
            label: `Advanced Pay`,
            children: <AdvancedPay CustomerDetails={CustomerDetails} />,
        },
        {
            key: '5',
            label: `Credit Pay`,
            children: <Creditpay CustomerDetails={CustomerDetails} />,
        },
        {
            key: '6',
            label: `Debit Pay`,
            children: <Debitpay CustomerDetails={CustomerDetails} />,
        }
    ];
    const onChange = (key) => {
        console.log(key);
    };
  return (
    <div>
        <Tabs onChange={onChange} items={items} />
    </div>
  )
}

export default TabDetails