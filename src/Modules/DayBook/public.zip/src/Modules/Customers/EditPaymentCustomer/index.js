import React from 'react'
import EditCPayment from './Partials/EditCPayment'
import { TopTitle } from '../../../Components/Form/TopTitle'

const CustomerEditPayment = ({ setCustomer, getCustomer }) => {
  return (
    <div>
        <TopTitle Heading={'view Customer Payment'} />
        <EditCPayment setCustomer={setCustomer} getCustomer={getCustomer}/>
    </div>
  )
}

export default CustomerEditPayment