import React, { useEffect, useState } from 'react'
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { Table } from '../../../../Components/Table';
import { Modal } from '../../../../Components/Modal';
import { Col, Form, Modal as Modals } from 'antd';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { Row } from '../../../../Components/Row';
import { Select } from '../../../../Components/Form/Select';
import Input from '../../../../Components/Form/Input';
import { phoneValidator } from '../../../../utils/PhnNumberValidator'
import CustomerPay from '../../CustomerPayment/Partials/CustomerPay';
import request from '../../../../utils/request';
import { toast } from 'react-toastify';
import dayjs from 'dayjs';


const EditCPayment = ({ setCustomer, getCustomer }) => {

  const [form] = Form.useForm();

  const URL = 'customers/add_customer/';

  const URLS = 'customers/customer_payments_view/';

  const [selectedCustomer, setSelectedCustomer] = useState({})

  // ======  Modal Open ========
  const [isModalOpen, setIsModalOpen] = useState(false);

  // ======  Modal Title and Content ========
  const [modalTitle, setModalTitle] = useState("");
  const [modalContent, setModalContent] = useState(null);

  const [advancedSet, setAdvancedSet] = useState(false)
  const [creditSet, setCreditSet] = useState(false)
  const [debitSet, setDebitSet] = useState(false)

  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onViewStudent = (record) => {
    setModalContent('gfdhfc');
    setModalTitle("View Details");
    showModal();
  }

  const onFinish = (values) => {
    console.log('Success:', values);
    let result = {
      id: values.mobile_number,
      payment_type: values.payment,
      // mobile_number: values.mobile_number,
  };
    Viewcustomer(result)
  };

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  const Viewcustomer = (values) => {
    request.post(`${URLS}`, values)
        .then(function (response) {
            console.log(response);
            // getSupplier(values)
            toast.success("Success")
            setDataSource(response.data)
            form.resetFields();
        })
        .catch(function (error) {
            console.log(error);
            toast.error("Faild")
        });
}


  useEffect(() => {
    GetCustomer();
  }, [])


  const GetCustomer = (values) => {
    request.get(`${URL}`, values)
      .then(function (response) {
        console.log(response.data, 'supplier');
        setCustomer(response.data)
      })
      .catch(function (error) {
        console.log(error);
      });
  }

  // ===========  Customer MobileNumber Data =========

  const CustomerMobiles = getCustomer?.map(mob => ({ label: mob.mobile_number, value: mob.id }))

  const handleSelectedCustomer = (value) => {
    const SelectedCustomerDetails = getCustomer?.find((mem) => mem.id === value)
    setSelectedCustomer(SelectedCustomerDetails);
  }

  const activrBtns = (record) => {
    // setActivebtn(!activebtn);
    console.log(record, 'deddddddddd');
    const filtered = dataSource.map((prop) => {
      if (prop.id === record.id) {
        prop.status = !prop.status
        return prop
      } return prop
    })
    const otherAllFiltered = dataSource.filter((prop) => prop.id != record.id)
    console.log(filtered, 'filtered')
    console.log(otherAllFiltered, 'other filtered')
    setDataSource(filtered)
  };

  const onDeleteStudent = (record) => {
    Modals.confirm({
      title: "Are you sure, you want to delete this student record?",
      okText: "Yes",
      okType: "danger",
      onOk: () => {
        setDataSource((pre) => {
          return pre.filter((student) => student.id !== record.id);
        });
      },
    });
  };
  const [tableData, setTableData] = useState();

  const [dataSource, setDataSource] = useState([])

  const option = [
    {
      label: 'Advanced',
      value: 'Advance'
    },
    {
      label: 'Credit',
      value: 'Credit'
    },
    {
      label: 'Debt',
      value: 'Debt'
    }
  ]

  const columns = [
    {
      title: 'S.No',
      render: (value, item, index) => index + 1,
    },
    {
      title: 'Date',
      dataIndex: 'date',
      render: (date) => {
        return dayjs(date).format('DD\\MM\\YYYY');
      },
    },
    {
      title: 'Customer Name',
      dataIndex: 'customer_name',
    },
    {
      title: 'Phone No',
      dataIndex: 'mob_no',
    },
    {
      title: 'Amount',
      dataIndex: 'amt',
    },
    {
      title: 'Action',
      render: (record, i) => {
        console.log(record, 'ddddddddd')
        return (
          <>
            <Flex spaceEvenly>
              <Button.Success onClick={() => {
                onEditStudent(record);
              }} text={<EditOutlined />} />

              <Button.Success text={<EyeOutlined />} onClick={() => {
                onViewStudent(record);
              }} />
              {/* <Button.Danger text={<DeleteOutlined />} onClick={() => onDeleteStudent(record)} /> */}

            </Flex>
          </>
        );
      },

    }
  ]
  const onEditStudent = (record) => {
    console.log(isModalOpen, 'called')
    showModal();
    setModalTitle("update");
    setModalContent(<CustomerPay />);
  }

  const hiddenColumnData = (values) => {
    console.log(values, 'fffff')
    if (values === 'advanced') {
      setAdvancedSet(true);
      setCreditSet(false);
      setDebitSet(false);
    }
    else if (values === 'credit') {
      setAdvancedSet(false);
      setCreditSet(true);
      setDebitSet(false);
    }
    else if (values === 'debit') {
      setAdvancedSet(false);
      setCreditSet(false);
      setDebitSet(true);
    }
    else {
      setAdvancedSet(false);
      setCreditSet(false);
      setDebitSet(false);
    }
  }
  return (
    <div>
      <Form
        name="basic"
        labelCol={{
          span: 24,
        }}
        wrapperCol={{
          span: 24,
        }}
        onFinish={onFinish}
        onFinishFailed={onFinishFailed}
        autoComplete="off"
      >
        <Row gutter={[12, 12]}>
          <Col span={24} md={10}>
            <Select options={option} name={'payment'} onChange={hiddenColumnData} label={'Transaction'} placeholder={'Select'}
              rules={[{
                required: 'true',
                message: 'Enter the details !'
              }]} />
          </Col>
          <Col span={24} md={10}>
            <Select options={CustomerMobiles} showSearch label={'Mobile Number'}
              placeholder={'Select Number'} name={'mobile_number'}
              onChange={handleSelectedCustomer} />
          </Col>
          <Col span={24} md={4}><br /><br />
            <Button.Primary text={'Submit'} htmlType='submit' />
          </Col>
        </Row>
      </Form>
      <br />
      <Table columns={columns.filter(Boolean)} data={dataSource} />
      <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />

    </div>
  )
}

export default EditCPayment