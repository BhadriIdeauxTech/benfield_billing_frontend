import React, { useEffect } from 'react'
import { Table } from '../../../../Components/Table';
import { Modal } from '../../../../Components/Modal';
import { useState } from 'react';
import { Modal as Modals } from 'antd';
import Flex from '../../../../Components/Flex';
import Button from '../../../../Components/Form/Button';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import { useNavigate, useParams } from 'react-router-dom';
import AddingCustomers from '../../AddCustomers/Partials/AddCustomers';
import request from '../../../../utils/request';

const TableEdit = ({ setCustomer, getCustomer }) => {

    const navigate = useNavigate();
    
    const [date, setDate] = useState('');

    const { id } = useParams();

    const URL = 'customers/add_customer/';
    
    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const onViewStudent = (record) => {
        setModalContent('gfdhfc');
        setModalTitle("View Details");
        showModal();
    }

    useEffect(() => {
        GetSupplier();
    }, [])

    const GetSupplier = (values) => {
        request.get(`${URL}`, values)
            .then(function (response) {
                console.log(response.data, 'supplier');
                // setSupplier(response.data)
                setDataSource(response.data)
            }, [id])
            .catch(function (error) {
                console.log(error);
            });
    }
    console.log(getCustomer, 'getSuppliergetSupplier')

  
    const [tableData, setTableData] = useState();
    const [dataSource, setDataSource] = useState([])


    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        {
            title: 'Customer Name',
            dataIndex: 'customer_name',
        },
        {
            title: 'Phone No',
            dataIndex: 'mobile_number',
        },
        {
            title: 'Advanced Amount',
            dataIndex: 'advanced_amt',
        },
        {
            title: 'Debt Amount',
            dataIndex: 'debit_amt',
        },
        {
            title: 'Action',
            render: (record, i) => {
                console.log(record, 'ddddddddd')
                return (
                    <>
                        <Flex spaceEvenly>
                            <Button.Success onClick={() => {
                                onEditStudent(record);
                            }} text={<EditOutlined />} />

                            {/* <Button.Danger text={<DeleteOutlined />} onClick={() => onDeleteStudent(record)} /> */}
                            <Button.Primary text={'profile'} onClick={() => navigate(`/CustomerProfiless/${record.id}`)} />
                        </Flex>
                    </>
                );
            },

        }
    ]
    const onEditStudent = (record) => {
        console.log(isModalOpen, 'called')
        showModal();
        // setModalTitle("update");
        setModalContent(<AddingCustomers />);
    }
    return (
        <div>
            
            <Table columns={columns} data={dataSource} />
            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />
        </div>
    )
}

export default TableEdit