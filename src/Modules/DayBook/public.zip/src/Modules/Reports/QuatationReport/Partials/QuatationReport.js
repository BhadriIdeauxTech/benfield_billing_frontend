import React from 'react'
import { CardOnBottom, CardOnTop, TableStyle } from '../../SaleReport/Partials/Style';
import { Row } from '../../../../Components/Row';
import { Col, Space, Tag } from 'antd';
import { CustomDateRangePicker } from '../../../../Components/Form/CustomDateRangePicker';
import Button from '../../../../Components/Form/Button';
import { PrinterFilled } from '@ant-design/icons';
import CardPayment from './CardPayment';
import { Table } from '../../../../Components/Table';
import { useState } from 'react';
import { TbArrowsExchange } from 'react-icons/tb';
import Flex from '../../../../Components/Flex';
import Label from '../../../../Components/Form/Label';
import { Select } from '../../../../Components/Form/Select';

const QuatationReport = () => {
    const [selectedDate, setSelectedDate] = useState('null')
    const handleOnChange = (date) => {
        setSelectedDate(date);
    };

    const columns = [
        {
            title: 'Date',
            dataIndex: 'date',
            key: 'date',
            render: text => <a>{text}</a>,
        },
        {
            title: 'Invoice Number',
            dataIndex: 'invoice_number',
            key: 'invoice_number',
        },
        {
            title: 'Transaction Type',
            dataIndex: 'transaction_type',
            key: 'transaction_type',
        },
        {
            title: 'Payment Type',
            key: 'payment_type',
            dataIndex: 'payment_type',
            render: payment_type => (
                <span>
                    {payment_type.map(payment_type => {
                        let color = payment_type.length > 5 ? 'geekblue' : 'green';
                        if (payment_type === 'cheque') {
                            color = 'volcano';
                        }
                        return (
                            <Tag color={color} key={payment_type}>
                                {payment_type.toUpperCase()}
                            </Tag>
                        );
                    })}
                </span>
            ),
        },
        {
            title: 'Amount',
            dataIndex: 'amount',
            key: 'amount',
        },
        {
            title: 'Balance Due',
            dataIndex: 'balance_due',
            key: 'balance_due',
        },

    ];
    const sales = [
        {
            label: 'This Month',
            value: 'thismonth'
        },
        {
            label: 'Quotation',
            value: 'quotation'
        },
        {
            label: 'Year',
            value: 'year'
        },
        {
            label: 'Between Dates',
            value: 'dates'
        },
    ]
    const data = [
        {
            key: '1',
            date: '14/04/2023',
            invoice_number: 32771,
            party_name: 'Jack',
            payment_type: ['others'],
            amount: '2500',
            balance_due: '500'
        },
        {
            key: '2',
            date: '25/04/2023',
            invoice_number: 42110,
            party_name: 'Mach',
            payment_type: ['cheque'],
            amount: '32000',
            balance_due: '2000'
        },
        {
            key: '3',
            date: '07/04/2023',
            invoice_number: 32780,
            party_name: 'James',
            payment_type: ['cash'],
            amount: '14000',
            balance_due: '1500'
        },
    ];

    return (
        <div>
            <CardOnTop>
            <Row gutter={[24, 24]} style={{ padding: '10px 0' }}>
                    <Col span={24} md={10}>
                        <Flex centerVertically>
                            <b>Between</b>&nbsp;&nbsp; <TbArrowsExchange />
                            &nbsp;&nbsp;
                            <Space direction="vertical" size={12}>
                                <CustomDateRangePicker name={'date_range'} onChange={handleOnChange} />
                            </Space>
                        </Flex>
                    </Col>
                    <Col span={24} md={7}>
                        <Label>Report</Label>
                        <Select options={sales} placeholder={'Select'} />
                    </Col>
                    <Col span={24} md={5}></Col>
                    <Col span={24} md={2} >
                        <Button.Primary icon={<PrinterFilled />} />
                    </Col>
                </Row>
                {/* <CardPayment /> */}

            </CardOnTop >
            <CardOnBottom>
                <Row gutter={[24, 24]}>
                    <Col span={24} md={20}>
                        <h1>Transactions :</h1>
                        {/* <SearchBar /> */}
                    </Col>

                    <TableStyle>
                        <Table columns={columns} data={data} />
                    </TableStyle>
                </Row>
            </CardOnBottom>
        </div>
    )
}

export default QuatationReport