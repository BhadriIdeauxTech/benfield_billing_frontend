import React from 'react'
import TotalCustomerReport from './Partials/TotalCustomerReport'

const TotalCustomersMain = () => {
  return (
    <div>
        <TotalCustomerReport />
    </div>
  )
}

export default TotalCustomersMain