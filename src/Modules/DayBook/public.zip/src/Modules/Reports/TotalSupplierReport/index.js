import React from 'react'
import TotalSupplier from './Partials/TotalSupplier'

const TotalSupplierMain = () => {
  return (
    <div>
        <TotalSupplier />
    </div>
  )
}

export default TotalSupplierMain