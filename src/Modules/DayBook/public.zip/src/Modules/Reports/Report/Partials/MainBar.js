import React from 'react'
import { MainLayout } from '../../../../Layout/style'
import TopSection from './TopMenu'
import BottomSection from './SideBar'
import SideSection from './SideBar'

const PurchaseReport = () => {
  return (
    <div>
        <MainLayout sideBox = {<SideSection/>} headBox={<TopSection />} secondbox={<BottomSection/>} />
    </div>
  )
}

export default PurchaseReport