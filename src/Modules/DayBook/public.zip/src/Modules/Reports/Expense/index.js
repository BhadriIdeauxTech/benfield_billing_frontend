import React from 'react'
import ExpenseReport from './Partials/ExpenseReport'

const ExpenseReportMain = () => {
  return (
    <div>
        <ExpenseReport />
    </div>
  )
}

export default ExpenseReportMain