import { Col, Form } from 'antd'
import React, { Fragment, useState } from 'react'
import dayjs from 'dayjs';
import { phoneValidator } from '../../../../utils/PhnNumberValidator'
import { AiOutlinePlus } from 'react-icons/ai';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { Row } from '../../../../Components/Row';
import Input from '../../../../Components/Form/Input';
import { CustomInputNumber } from '../../../../Components/Form/CustomInputNumber';
import { CustomDatePicker } from '../../../../Components/Form/CustomDatePicker';
import { TextAreas } from '../../../../Components/Form/TextArea';
import { Select } from '../../../../Components/Form/Select';
import Button from '../../../../Components/Form/Button';
import { Modal } from '../../../../Components/Modal';
import AddSpplier from '../../../Suppliers/AddSupplier';


export const PurchaseFormHeader = ({ setSaleorder }) => {
    const [form] = Form.useForm();
    const [mobileshow, setMobileshow] = useState(false)
    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    // ======  Selected Date ========
    const [selectedDate, setSelectedDate] = useState(dayjs().format('MMMM DD, YYYY'));

    const handleMobileShow = () => {
        setMobileshow(!mobileshow)
    }
    const onViewRow = () => {
        // setModalTitle("Add Details");
        setModalContent(<AddSpplier />);
        showModal();
    }

    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };

    // ==========  Date Change =======
    const handleOnChange = (date) => {
        setSelectedDate(date);
    };
    const option = [
        {
            label: 'Tamil Nadu',
            value: 'TamilNadu'

        },
        {
            label: 'Kerala',
            value: 'Kerala'
        },
        {
            label: 'AndraPradesh',
            value: 'AndraPradesh'
        }
    ]

    const CusData = [
        {
            label: 'rejin',
            value: 'rejin'
        },
        {
            label: 'gladine',
            value: 'gladine'
        },
        {
            label: 'saras',
            value: 'saras'
        },
        {
            label: 'ishwarya',
            value: 'ishwarya'
        },

    ]
    const onFinish = (values) => {
        const record = { ...values, selected_date: selectedDate };
        setSaleorder(record)
        console.log('Success:', values);
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };



    return (
        <Fragment style={{ margin: '0 auto', width: '95%' }}>
            <TopTitle Heading={'Purchase'} />
            <Row gutter={[24, 24]} style={{ backgroundColor: 'white', padding: '25px', borderRadius: '10px', boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)' }}>
                <Col span={24} md={16}>
                    <Row gutter={[12, 12]}>
                        <Col span={24} md={12}>
                            <Input label={'Mobile Number'} name={'mobile_number'} onChange={handleMobileShow} placeholder={'Mobile Number'}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the mobile number !'
                                },
                                { validator: phoneValidator },
                                {
                                    max: 10,
                                    message: 'Only 10 Digit enter'
                                },
                                {
                                    min: 10,
                                    message: 'to Short'
                                }
                                ]} />
                        </Col>

                        {mobileshow ?
                            (
                                <>
                                    <Col span={24} md={12}>
                                        <Input label={'GST IN'} name={'GSTIN'} placeholder={'GST IN'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the details !'
                                            },]}
                                        />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <Input label={'Email ID'} name={'email'} placeholder={'Email ID'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the details !'
                                            },]} />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <Input label={'Company Name'} name={'company_name'} placeholder={'Company Name'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the mobile number !'
                                            },]} />
                                    </Col>

                                    <Col span={24} md={12}>
                                        <TextAreas label={'Address'} name={'address'} placeholder={'Address'}
                                            rules={[{
                                                required: 'true',
                                                message: 'Enter the mobile number !'
                                            },]} />
                                    </Col>
                                </>
                            )
                            : <Col span={24} md={24}>
                                <Button.Primary shape='round' onClick={() => onViewRow()} size='large' icon={<AiOutlinePlus style={{ fontSize: '1rem', fontWeight: 1000 }} />} text={'Add Supplier'} />
                            </Col>}
                    </Row>
                </Col>
                <Col span={24} md={8}>
                    <Row gutter={[12, 12]}>
                        <Col span={24} md={24}>
                            <CustomInputNumber label={'Purchase Invoice Number'} name={'purchase_invoice_no'} placeholder={'Invoice Number'} 
                            rules={[{
                                required: 'true',
                                message: 'Enter the details !'
                            },]} />
                        </Col>
                        <Col span={24} md={24}>
                            <CustomDatePicker label={'Purchase Date'} onChange={handleOnChange} name={'purchase_date'}
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the details !'
                                },]} />
                        </Col>
                        <Col span={24} md={24}>
                            <Input label={'State'} name={'state_of_supply'} placeholder={'Select selet'} 
                                rules={[{
                                    required: 'true',
                                    message: 'Enter the mobile number !'
                                },]} />
                        </Col>
                    </Row>
                </Col>


            </Row>

            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />
        </Fragment>
    )
}
