import React from 'react'
import { PurchaseEntryPage } from './Partials/PurchseEntryPage'

const Purchase = ({setSaleorder,getSaleorders,selectedDate}) => {
  return (
    <div>
        <PurchaseEntryPage setSaleorder={setSaleorder}  getSaleorders={getSaleorders} selectedDate={selectedDate}/>
    </div>
  )
}

export default Purchase