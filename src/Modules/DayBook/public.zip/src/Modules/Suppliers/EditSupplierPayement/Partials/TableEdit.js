import React from 'react'
import { Modal } from '../../../../Components/Modal'
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons'
import Button from '../../../../Components/Form/Button'
import Flex from '../../../../Components/Flex'
import { useState } from 'react'
import { Col, Form, Modal as Modals } from 'antd'
import { Table } from '../../../../Components/Table'
import { Row } from '../../../../Components/Row'
import { Select } from '../../../../Components/Form/Select'
import Input from '../../../../Components/Form/Input'
import request from '../../../../utils/request'
import { useEffect } from 'react'
import { toast } from 'react-toastify'
import dayjs from 'dayjs';

const TableEdit = ({ setSupplier, getSupplier }) => {

    const [form] = Form.useForm();

    const URL = 'supplier/add_supplier/'

    const URLS = 'supplier/supplier_payments_view/'

    const [selectedSupplier, setSelectedSupplier] = useState({})

    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    const showModal = () => {
        setIsModalOpen(true);
    };
    
    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const onViewStudent = (record) => {
        setModalContent('gfdhfc');
        setModalTitle("View Details");
        showModal();
    }

    const onFinish = (values) => {
        console.log('Success:', values);
        let result = {
            id: values.mobile_number,
            payment_type: values.payment,
            // mobile_number: values.mobile_number,
        };
        Viewsupplier(result)

    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };


    const Viewsupplier = (values) => {
        request.post(`${URLS}`, values)
            .then(function (response) {
                console.log(response);
                // getSupplier(values)
                toast.success("Success")
                setDataSource(response.data)
                form.resetFields();
            })
            .catch(function (error) {
                console.log(error);
                toast.error("Faild")
            });
    }


    useEffect(() => {
        GetSupplier();
    }, [])
    useEffect(() => {

        form.setFieldsValue({ supplier: selectedSupplier.id })

    }, [selectedSupplier])

    const GetSupplier = (values) => {
        request.get(`${URL}`, values)
            .then(function (response) {
                console.log(response.data, 'supplier');
                setSupplier(response.data)
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    console.log(getSupplier, 'getSuppliergetSupplier')

    // ===========  Supplier MobileNumber Data =========

    const SupplierMobiles = getSupplier.map(mob => ({ label: mob.mobile_number, value: mob.id }))

    const handleSelectedSupplier = (value) => {

        const SelectedSupplierDetails = getSupplier.find((mem) => mem.id === value)
        setSelectedSupplier(SelectedSupplierDetails);
    }


    const onDeleteStudent = (record) => {
        Modals.confirm({
            title: "Are you sure, you want to delete this student record?",
            okText: "Yes",
            okType: "danger",
            onOk: () => {
                setDataSource((pre) => {
                    return pre.filter((student) => student.id !== record.id);
                });
            },
        });
    };
    const [tableData, setTableData] = useState();
    const [dataSource, setDataSource] = useState([])

    const option = [
        {
            label: 'Advanced',
            value: 'Advance'
        },
        {
            label: 'Credit',
            value: 'Credit'
        },
        {
            label: 'Debt',
            value: 'Debt'
        }
    ]
    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        {
            title: 'Date',
            dataIndex: 'date',
            render: (date) => {
                return dayjs(date).format('DD\\MM\\YYYY');
              },
        },
        {
            title: 'Supplier Name',
            dataIndex: 'supplier_name',
        },
        {
            title: 'Phone No',
            dataIndex: 'mob_no',
        },
        {
            title: 'Amount',
            dataIndex: 'amt',
        },
        {
            title: 'Action',
            render: (record, i) => {
                console.log(record, 'ddddddddd')
                return (
                    <>
                        <Flex spaceEvenly>
                            <Button.Success onClick={() => {
                                onEditStudent(record);
                            }} text={<EditOutlined />} />

                            <Button.Success text={<EyeOutlined />} onClick={() => {
                                onViewStudent(record);
                            }} />
                            {/* <Button.Danger text={<DeleteOutlined />} onClick={() => onDeleteStudent(record)} /> */}

                        </Flex>
                    </>
                );
            },

        }
    ]
    const onEditStudent = (record) => {
        setModalContent('gfdhfc');
        setModalTitle("View Details");
        showModal();
        // console.log(isModalOpen, 'called')
        // showModal();
        // setModalTitle("update");
        // setModalContent(<SupplierPayementDetails />);
    }
    return (
        <div>
            <Form
                name="basic"
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off"
            >
                <Row gutter={[12, 12]}>
                    <Col span={24} md={10}>
                        <Select options={option} name={'payment'} label={'Transaction'} placeholder={'Select'}
                            rules={[{
                                required: 'true',
                                message: 'Enter the details !'
                            }]} />
                    </Col>
                    <Col span={24} md={10}>
                        <Select options={SupplierMobiles} showSearch label={'Mobile Number'}
                            placeholder={'Select Number'} name={'mobile_number'}
                            onChange={handleSelectedSupplier}
                            rules={[
                                {
                                    required: true,
                                    message: 'Select Mobile Number !'
                                }
                            ]} />
                        <Input name={'supplier'} display={"none"} />
                        
                    </Col>
                    <Col span={24} md={4}><br/><br/>
                        <Button.Primary text={'Submit'} htmlType='submit' />
                    </Col>
                </Row>

            </Form>
            <br />
            <Table columns={columns} data={dataSource} />
            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />

        </div>
    )
}

export default TableEdit