import React, { useState } from 'react'
import { Table } from '../../../../Components/Table';
import { Modal } from '../../../../Components/Modal';
import { Form, Modal as Modals } from 'antd';
import { DeleteOutlined, EditOutlined, EyeOutlined } from '@ant-design/icons';
import Flex from '../../../../Components/Flex';
import Button from '../../../../Components/Form/Button';
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { useNavigate, useParams } from 'react-router-dom';
import Addsppliers from '../../AddSupplier/Partials/Addsppliers';
import { useEffect } from 'react';
import request from '../../../../utils/request';

const TableView = ({setSupplier,getSupplier}) => {

    const URL = 'supplier/add_supplier/'

    const { id } = useParams();
    
    const [data, setData] = useState(null);

    const [form] = Form.useForm();

    const nevigate = useNavigate();

    const [selectedSupplier, setSelectedSupplier] = useState({})

    const [date, setDate] = useState('');
    // const [ischecked, setIschecked] = useState(false);
    // ======  Modal Open ========
    const [isModalOpen, setIsModalOpen] = useState(false);

    // ======  Modal Title and Content ========
    const [modalTitle, setModalTitle] = useState("");
    const [modalContent, setModalContent] = useState(null);

    const showModal = () => {
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
    };
   
    useEffect(() => {
        GetSupplier();
    }, [])

    useEffect(() => {
        form.setFieldsValue({ supplier_name: selectedSupplier.supplier_name })
        form.setFieldsValue({ mobile_number: selectedSupplier.mobile_number }) 
    }, [selectedSupplier])

    const GetSupplier = (values) => {
        request.get(`${URL}`, values)
            .then(function (response) {
                console.log(response.data, 'supplier');
                // setSupplier(response.data)
                setDataSource(response.data)
                .then(response => response.json())
                .then(data => setData(data))
                
            }, [id])
            .catch(function (error) {
                console.log(error);
            });
    }
    console.log(getSupplier, 'getSuppliergetSupplier')

    // const onDeleteStudent = (record) => {
    //     Modals.confirm({
    //         title: "Are you sure, you want to delete this student record?",
    //         okText: "Yes",
    //         okType: "danger",
    //         onOk: () => {
    //             setDataSource((pre) => {
    //                 return pre.filter((student) => student.id !== record.id);
    //             });
    //         },
    //     });
    // };
    const [tableData, setTableData] = useState();
    const [dataSource, setDataSource] = useState([])


    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        // {
        //     title: 'Supplier Name',
        //     dataIndex: 'id',
        // },
        {
            title: 'Supplier Name',
            dataIndex: 'supplier_name',
        },
        {
            title: 'Phone No',
            dataIndex: 'mobile_number',
        },
        {
            title: 'Advanced Amount',
            dataIndex: 'advanced_amt',
        },
        {
            title: 'Debt Amount',
            dataIndex: 'debt_amt',
        },
        
        {
            title: 'Action',
            render: (record, i) => {
                console.log(record, 'ddddddddd')
                return (
                    <>
                        <Flex spaceEvenly>
                            <Button.Success onClick={() => {
                                onEditStudent(record);
                            }} text={<EditOutlined />} />
                            {/* <Button.Danger text={<DeleteOutlined />} onClick={() => onDeleteStudent(record)} /> */}
                            <Button.Primary text={'profile'} onClick={() => nevigate(`/SupplierProfiles/${record.id}`)} />
                        </Flex>
                    </>
                );
            },

        }
    ]
    const onEditStudent = (record) => {
        console.log(isModalOpen, 'called')
        showModal();
        setModalTitle("update");
        setModalContent(<Addsppliers />);
    }
    return (
        <div>
            <TopTitle Heading={'View Supplier List'} />
            <Table columns={columns} data={dataSource} />
            <Modal isVisible={isModalOpen} handleOk={handleOk} handleCancel={handleCancel} width={1000} modalTitle={modalTitle} modalContent={modalContent} />

        </div>
    )
}

export default TableView