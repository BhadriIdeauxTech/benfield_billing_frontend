import React from 'react'
import { Table } from '../../../../Components/Table'
import { useState } from 'react'
import { useEffect } from 'react';

const PurchaseRetun = ({ getSupplier }) => {

    const [purchaseReunBillList, setPurchaseReunBillList] = useState([]);

    useEffect(() => {
        setPurchaseReunBillList(getSupplier.purchase_return_list)
    }, [getSupplier])
    
    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        {
            title: 'Date',
            dataIndex: 'date',
        },
        {
            title: 'Bill No',
            dataIndex: 'invoice_no',
        },
        {
            title: 'Transaction',
            dataIndex: 'transaction_type',
        },
        {
            title: 'Payment',
            dataIndex: 'payment_type',
        },
        {
            title: 'Bill Amount',
            dataIndex: 'bill_amt',
        },
        {
            title: 'Balance',
            dataIndex: 'balance_due',
        },
    ]
  return (
    <div>
         <Table columns={columns} data={purchaseReunBillList} />
    </div>
  )
}

export default PurchaseRetun