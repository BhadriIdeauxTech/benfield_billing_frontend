import React from 'react'
import { Table } from '../../../../Components/Table'
import Column from 'antd/es/table/Column'
import { useState } from 'react'
import request from '../../../../utils/request'
import { useEffect } from 'react'
import { Form } from 'antd'

const PurchaseTabs = ({ getSupplier }) => {

    const [PurchaseBillList, setPurchaseBillList] = useState([]);

    console.log(getSupplier, 'tttttttttttttttttttttt')
    console.log(PurchaseBillList, 'PurchaseBillList')

    useEffect(() => {
        setPurchaseBillList(getSupplier.purchase_bill_lis)
    }, [getSupplier])
    
    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        {
            title: 'Date',
            dataIndex: 'date',
        },
        {
            title: 'Bill No',
            dataIndex: 'invoice_no',
        },
        {
            title: 'Transaction',
            dataIndex: 'transaction_type',
        },
        {
            title: 'Payment',
            dataIndex: 'payment_type',
        },
        {
            title: 'Bill Amount',
            dataIndex: 'bill_amt',
        },
        {
            title: 'Balance',
            dataIndex: 'balance_due',
        },
    ]
    return (
        <div>
            <Table columns={columns} data={PurchaseBillList} />
        </div>
    )
}

export default PurchaseTabs