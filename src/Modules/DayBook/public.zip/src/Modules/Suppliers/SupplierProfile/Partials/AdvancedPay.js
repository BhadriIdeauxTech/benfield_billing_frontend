import React from 'react'
import { Table } from '../../../../Components/Table'
import { useState } from 'react'
import { useEffect } from 'react';
import dayjs from 'dayjs';

const AdvancedPay = ({ getSupplier }) => {

    const [advancedPayBillList, setAdvancedPayBillList] = useState([]);

    useEffect(() => {
        setAdvancedPayBillList(getSupplier.advance_list)
    }, [getSupplier])
    
    const [dataSource, setDataSource] = useState([])
    const columns = [
        {
            title: 'S.No',
            render: (value, item, index) => index + 1,
        },
        {
            title: 'Date',
            dataIndex: 'date',
            render: (date) => {
                return dayjs(date).format('DD\\MM\\YYYY');
              },
        },
        {
            title: 'Bill No',
            dataIndex: 'invoice_no',
        },
        {
            title: 'Transaction',
            dataIndex: 'transaction_type',
        },
        {
            title: 'Payment',
            dataIndex: 'payment_type',
        },
        {
            title: 'Bill Amount',
            dataIndex: 'bill_amt',
        },
        {
            title: 'Balance',
            dataIndex: 'balance_due',
        },
    ]
  return (
    <div>
        <Table columns={columns} data={advancedPayBillList} />
    </div>
  )
}

export default AdvancedPay