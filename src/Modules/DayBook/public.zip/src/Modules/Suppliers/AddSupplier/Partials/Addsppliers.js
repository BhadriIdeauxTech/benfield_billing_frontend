import { Col, Form } from 'antd';
import React from 'react'
import { TopTitle } from '../../../../Components/Form/TopTitle';
import { Row } from '../../../../Components/Row';
import Input from '../../../../Components/Form/Input';
import { CustomInputNumber } from '../../../../Components/Form/CustomInputNumber';
import { useState } from 'react';
import Button from '../../../../Components/Form/Button';
import Flex from '../../../../Components/Flex';
import { TextAreas } from '../../../../Components/Form/TextArea';
import Switch from '../../../../Components/Form/Switch';
import Label from '../../../../Components/Form/Label';
import request from '../../../../utils/request';
import { toast } from 'react-toastify';

const Addsppliers = ({ getSupplier }) => {
    const [form] = Form.useForm();

    const [switched, setSwitched] = useState(false);

    const URL = 'supplier/add_supplier/'

    const onFinish = (values) => {
        Addsupplier(values)
        console.log('Success:', values);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    // const member = useSelector(state => state);
    // console.log(member)

    const onhandleSwitch = (checked) => {
        setSwitched(checked);
    };

    const Addsupplier = (values) => {
        request.post(`${URL}`, values)
            .then(function (response) {
                console.log(response);
                // getSupplier(values)
                toast.success("Success")
                form.resetFields();
            })
            .catch(function (error) {
                console.log(error);
                toast.error("Faild")
            });
    }

    const onReset = () => {
        form.resetFields();
    }

    // const option = [
    //     { label: 'Tamil Nadu', value: 'TamilNadu' },
    //     { label: 'Kerala', value: 'Kerala' },
    //     { label: 'AndraPradesh', value: 'AndraPradesh' }
    // ]

    return (
        <div>
            <Form
                form={form}
                labelCol={{
                    span: 24,
                }}
                wrapperCol={{
                    span: 24,
                }}
                initialValues={{
                    bank_detail: false
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                autoComplete="off">
                <Row gutter={[24, 24]}>

                    <Col span={24} md={12}>
                        <Input label={'Supplier Name'} placeholder={'Supplier Name'} name={'supplier_name'} rules={[
                            {
                                required: true,
                                message: 'Please Enter Supplier Name!',
                            }
                        ]} />
                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'Supplier Company'} placeholder={'Supplier Company'}
                            name={'supplier_company'} />
                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'Mobile number'} placeholder={'Contact Number'}
                            maxLength={10}
                            name={'mobile_number'}
                            onKeyPress={(event) => {
                                if (!/[0-9]/.test(event.key)) {
                                    event.preventDefault();
                                }
                            }}
                            rules={[
                                {
                                    required: true,
                                    message: 'Please enter Phone Number!',
                                },

                                {
                                    min: 10,
                                    message: 'Phone Number must be at least 10 characters!'
                                }
                            ]} />
                    </Col>

                    <Col span={24} md={12}>
                        <Input label={'Email id'} name={'email'} placeholder={"Email ID"}
                        />
                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'State'} name={'supplier_state'} placeholder={'Select selet'}
                        />
                    </Col>
                    <Col span={24} md={12}>
                        <Input label={'GSTIN'} placeholder={'GSTIN'} name={'gstin'}
                        />
                    </Col>
                    <Col span={24} md={12}>
                        <TextAreas label={'Address'} placeholder={'Address'} name={'supplier_address'}
                        />
                    </Col>


                    <Col span={24} md={12}>
                        <CustomInputNumber label={'Advance Amount'} precision={2} placeholder={'Advance Amount'}
                            name={'advanced_amt'} />
                    </Col>
                    <Col span={24} md={12} offset={12}></Col>
                    <Col span={24} md={24}>
                        <Label>Bank Details</Label>
                        <Col span={24} md={5}>
                            <Switch onChange={onhandleSwitch} checked={switched} name={'bank_detail'} />
                        </Col>
                        {switched ?
                            <Row gutter={[12, 12]} >
                                <Col span={24} md={12}>
                                    <Input label={'Account Name '} name={'account_name'} placeholder={'Account Name'}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please Enter Your Details!',
                                            }
                                        ]} />
                                </Col>

                                <Col span={24} md={12}>
                                    <CustomInputNumber label={'Account Number'} name={'bank_account_no'}
                                        placeholder={'Account Number'}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please Enter Your Details!',
                                            }
                                        ]} />
                                </Col>

                                <Col span={24} md={12}>
                                    <Input label={'Bank Name'} name={'bank_name'} placeholder={'Bank Name'}
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please Enter Your Details!',
                                            }
                                        ]} />
                                </Col>
                            </Row>
                            : null}

                    </Col>
                    <Col span={24} md={12} offset={12}></Col>
                    <Flex center gap={'20px'}>
                        <Button.Primary text={'ADD'} htmlType={'submit'} />
                        <Button.Danger text={'RESET'} htmlType={'cancel'} onClick={() => onReset()} />
                    </Flex>
                </Row>

            </Form>
        </div>
    )
}

export default Addsppliers