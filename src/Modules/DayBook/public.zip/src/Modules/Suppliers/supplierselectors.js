const getSupplier = state => state.AddingSupplier.supplier
const selectors = {
    getSupplier, 
}

export default selectors