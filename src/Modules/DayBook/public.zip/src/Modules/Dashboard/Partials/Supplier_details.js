import { Col } from 'antd'
import React from 'react'
import { DashSupplierData } from '../../../Assets/DashboardData'
import Flex from '../../../Components/Flex'
import { TopTitle } from '../../../Components/Form/TopTitle'
import { Row } from '../../../Components/Row'
import { Box, Card } from './style'
import { FormTitle } from '../../../Components/Form/FormTitle'

const Supplier_details = () => {
    return (
        <div>
            <Card>
                <FormTitle Title={'Supplier Debt'} />
                {DashSupplierData.map(({ h1, h3 ,amount,aumd}, i) => {
                    return (
                        <div style={{padding:'10px 0px'}}>
                           <Box key={i}>
                                <Flex centerVertically spaceBetween>
                                    <div><h1>{h1}</h1>
                                        <h3>{h3}</h3></div>
                                    <div>
                                        <p>{aumd}</p>
                                    </div>
                                </Flex>
                            </Box>
                        </div>
                    )
                })}
            </Card>
        </div>

    )
}

export default Supplier_details