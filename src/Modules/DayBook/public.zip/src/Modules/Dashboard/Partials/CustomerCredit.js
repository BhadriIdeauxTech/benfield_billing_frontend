import React from 'react'
import { Box, Card } from './style'
import { CustomercreditData } from '../../../Assets/DashboardData'
import { TopTitle } from '../../../Components/Form/TopTitle'
import { FormTitle } from '../../../Components/Form/FormTitle'
import Flex from '../../../Components/Flex'

const CustomerCredit = () => {
    return (
        <div>
            <Card>
                <FormTitle Title={'Customer Credit'} />
                {CustomercreditData.map(({ h1, h3, amount, aumd }, i) => {
                    return (
                        <div style={{ padding: '10px 0px' }}>

                            <Box key={i}>
                                <Flex centerVertically spaceBetween>
                                    <div><h1>{h1}</h1>
                                        <h3>{h3}</h3></div>
                                    <div>
                                        <p>{aumd}</p>
                                    </div>
                                </Flex>
                            </Box>


                        </div>
                    )
                })}
            </Card>
        </div>
    )
}

export default CustomerCredit