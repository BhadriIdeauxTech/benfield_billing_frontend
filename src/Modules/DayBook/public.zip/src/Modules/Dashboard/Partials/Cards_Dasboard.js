import { Col, Collapse } from 'antd'
import React from 'react'
import { FaRupeeSign } from 'react-icons/fa'
import { DashboardData } from '../../../Assets/DashboardData'
import Flex from '../../../Components/Flex'

import { Row } from '../../../Components/Row'
import { Cards } from './style'

const Cards_Dasboard = () => {
    return (
        <div>
            <Row gutter={[16, 16]} >
                {DashboardData.map(({ h1, p, prototype, icon, Amount,Total,heding }, i) => {
                    return (
                        <Col span={24} xs={24} sm={12} md={12} lg={6} >
                            <div key={i}>
                                <Cards>
                                    <Flex spaceBetween>
                                        <div>
                                            {icon}
                                        </div>
                                        <div >
                                            <h2>{Amount}</h2>
                                            <p>{p}</p>
                                           
                                        </div>
                                    </Flex>
                                    <Flex spaceBetween>
                                    <h1 >{h1}</h1>
                                   <h4>₹&nbsp;{Total}</h4>
                                    </Flex>   
                                    <Flex end>
                                    <p>{heding}</p></Flex>                               
                                </Cards>
                            </div>
                        </Col>
                    )
                })}
            </Row>

        </div>
    )
}

export default Cards_Dasboard