import React, { useState } from 'react'
import { TopTitle } from '../../../Components/Form/TopTitle'
import { Table } from '../../../Components/Table'
import { FoemTitle, FormTitle } from '../../../Components/Form/FormTitle'
import { Overhid } from './style'

const Least_quantity = () => {
    const columns = [
        {
            title: 'Product Name',
            dataIndex: 'product_name'
        },
        {
            title: 'HSN Code',
            dataIndex: 'hsncode'
        },
        {
            title: 'Qty in Stock',
            dataIndex: 'qty_stock'
        },
    ]
    const [dataSource, setDataSource] = useState([
        {
            id: 1,
            product_name: 'bridgestone',
            hsncode: '2',
            qty_stock: '10000',
        },
        {
            id: 2,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
        {
            id: 3,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
        {
            id: 4,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
        {
            id: 5,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
        {
            id: 6,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
        {
            id: 7,
            product_name: 'BRIDGESTONE',
            hsncode: '4',
            qty_stock: '20000',
        },
    ])
    return (
        <div>
            <FormTitle Title={'Least Quantity Products'} />
            <Overhid>
                <Table columns={columns} data={dataSource} />
            </Overhid>
        </div>
    )
}

export default Least_quantity