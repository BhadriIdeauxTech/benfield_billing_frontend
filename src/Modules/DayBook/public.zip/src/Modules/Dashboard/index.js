import { Col } from 'antd'
import React from 'react'
import { Row } from '../../Components/Row'
import Cards_Dasboard from './Partials/Cards_Dasboard'
import Least_quantity from './Partials/Least_quantity'
import Supplier_details from './Partials/Supplier_details'
import { Select } from '../../Components/Form/Select'
import CustomerCredit from './Partials/CustomerCredit'

const Dashboard = () => {

    const option = [
        { label: 'Admin', value: 'admin' },
        { label: 'GST Admin', value: 'gst_admin' },
        { label: 'GST Biller', value: 'gst_biller' },
        { label: 'Non GST Admin', value: 'non_gst_admin' },
        { label: 'Non GST Biller', value: 'non_gst_biller' },
    ]
    return (
        <div>
            <Cards_Dasboard/>
            {/* <Select options={option} label={'Supplier Name '} placeholder={'Supplier name'} rules={[
                            {
                                required: true,
                                message: 'Enter the Supplier Name !'
                            }
                        ]} /> */}
            <Row gutter={[12, 12]} style={{margin:'30px 0px'}}>
                <Col span={24} md={8}>
                    <Supplier_details />
                </Col>
                <Col span={24} md={8}>
                    <CustomerCredit />
                </Col>
                <Col span={24} md={8}  style={{margin:'30px 0px'}}>
                    <Least_quantity />
                </Col>
            </Row>

            
        </div>
    )
}
export default Dashboard